---
type: boundary_action
id: "BA-10"
gate: "[[G8 Campaign Deposit]]"
called_by: "Agent (A10 Brand)"
---
# BA-10: Campaign deposit

**Gate:** [[G8 Campaign Deposit]]
**Called by:** Agent (A10 Brand)

Brand funds A2E campaign.

## Pipeline
[[P31 Campaign creation]] then [[M46 Create escrow]]
