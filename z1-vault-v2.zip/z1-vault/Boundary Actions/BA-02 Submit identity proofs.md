---
type: boundary_action
id: "BA-02"
gate: "[[G1 Verification]]"
called_by: "Agent (A1-A5)"
---
# BA-02: Submit identity proofs

**Gate:** [[G1 Verification]]
**Called by:** Agent (A1-A5)

Submit proofs for verification.

## Pipeline
[[P01 Verification policy]] then [[M04 Set claim status]]
