---
type: boundary_action
id: "BA-12"
gate: "Governance"
called_by: "Agent (verified, gov_weight > 0)"
---
# BA-12: Cast vote

**Gate:** Governance
**Called by:** Agent (verified, gov_weight > 0)

Vote on active proposal.

## Pipeline
[[P02 Eligibility revalidation]] then [[M28 Vote escrow lock]] then [[M53 Record vote]]
