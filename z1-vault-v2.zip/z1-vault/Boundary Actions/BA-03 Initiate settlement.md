---
type: boundary_action
id: "BA-03"
gate: "[[G3 ACR Settlement]]"
called_by: "Agent (A_ACR, claim_status=pass)"
---
# BA-03: Initiate settlement

**Gate:** [[G3 ACR Settlement]]
**Called by:** Agent (A_ACR, claim_status=pass)

Request ACR to Z1U conversion.

## Pipeline
[[P10 Settlement eligibility]] then [[P11 Settlement ratio]] then [[M10 Settle ACR]]
