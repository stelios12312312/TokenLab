---
type: boundary_action
id: "BA-05"
gate: "[[G6 Governance Stake]]"
called_by: "Agent (ACR-verified)"
---
# BA-05: Governance lock

**Gate:** [[G6 Governance Stake]]
**Called by:** Agent (ACR-verified)

Lock Z1U for governance power.

## Pipeline
[[P36 Governance lock eligibility]] then [[M23 Governance lock]]
