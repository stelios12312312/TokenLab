---
type: boundary_action
id: "BA-06"
gate: "[[G6' Governance Unlock]]"
called_by: "Agent (staked)"
---
# BA-06: Governance unlock

**Gate:** [[G6' Governance Unlock]]
**Called by:** Agent (staked)

Request stake return after lock expiry.

## Pipeline
[[P39 Unlock eligibility]] then [[M24 Governance unlock]]
