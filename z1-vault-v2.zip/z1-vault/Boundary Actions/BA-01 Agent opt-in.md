---
type: boundary_action
id: "BA-01"
gate: "[[G0 Opt-in]]"
called_by: "Agent (any)"
---
# BA-01: Agent opt-in

**Gate:** [[G0 Opt-in]]
**Called by:** Agent (any)

Agent decides to join. Creates new E4 instance.

## Pipeline
[[M19 Create agent]]
