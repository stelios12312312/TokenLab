---
type: boundary_action
id: "BA-09"
gate: "[[G7 Transfer - Market]]"
called_by: "Agent (any Z1U holder)"
---
# BA-09: Transfer-trade

**Gate:** [[G7 Transfer - Market]]
**Called by:** Agent (any Z1U holder)

Z1U transfer or trade on external markets.

## Pipeline
[[M15 Transfer Z1U]]
