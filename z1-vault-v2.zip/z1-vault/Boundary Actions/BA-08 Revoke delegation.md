---
type: boundary_action
id: "BA-08"
gate: "[[G18' Governance Revocation]]"
called_by: "Agent (delegating)"
---
# BA-08: Revoke delegation

**Gate:** [[G18' Governance Revocation]]
**Called by:** Agent (delegating)

Recall delegated governance power.

## Pipeline
[[P25 Delegation policy]] then [[M27 Revoke delegation]]
