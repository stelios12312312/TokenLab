---
type: boundary_action
id: "BA-11"
gate: "Governance"
called_by: "Agent (Silver tier+, verified)"
---
# BA-11: Submit proposal

**Gate:** Governance
**Called by:** Agent (Silver tier+, verified)

Create governance proposal.

## Pipeline
[[P22 Proposal eligibility]] then [[P24 Parameter bounds]] then [[M52 Create proposal]]
