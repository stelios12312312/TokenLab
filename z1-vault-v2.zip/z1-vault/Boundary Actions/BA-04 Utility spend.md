---
type: boundary_action
id: "BA-04"
gate: "[[G5a Utility Spend]]"
called_by: "Agent (any Z1U holder)"
---
# BA-04: Utility spend

**Gate:** [[G5a Utility Spend]]
**Called by:** Agent (any Z1U holder)

Spend Z1U on utility SKU.

## Pipeline
[[P14 Utility spend split]] then G5a/G5b/G5c
