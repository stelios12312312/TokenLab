---
type: boundary_action
id: "BA-07"
gate: "[[G18 Governance Delegation]]"
called_by: "Agent (staked, verified)"
---
# BA-07: Delegate governance

**Gate:** [[G18 Governance Delegation]]
**Called by:** Agent (staked, verified)

Transfer voting power to delegate.

## Pipeline
[[P25 Delegation policy]] then [[M26 Delegate governance]]
