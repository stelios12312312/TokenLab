---
type: observable_metric
id: "OBS-15"
---
# OBS-15: net_emission(t)

**Definition:** G3+G4+G8 - G5a-G5b-G5c
**Measures:** Net supply expansion
