---
type: observable_metric
id: "OBS-12"
---
# OBS-12: sybil_rejection_rate(t)

**Definition:** G1 deny / G1 total
**Measures:** Anti-fraud effectiveness
