---
type: observable_metric
id: "OBS-04"
---
# OBS-04: velocity(t)

**Definition:** Z1U_Circulating(t) * turnover / period
**Measures:** Token circulation speed
