---
type: observable_metric
id: "OBS-06"
---
# OBS-06: treasury_runway(t)

**Definition:** T(t) / avg(G11+G12 per epoch)
**Measures:** Sustainability horizon
