---
type: observable_metric
id: "OBS-11"
---
# OBS-11: gini_acr(t)

**Definition:** Gini coefficient of ACR distribution
**Measures:** Recognition concentration
