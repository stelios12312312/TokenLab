---
type: observable_metric
id: "OBS-09"
---
# OBS-09: governance_participation(t)

**Definition:** Unique voters / eligible voters per epoch
**Measures:** Governance health
