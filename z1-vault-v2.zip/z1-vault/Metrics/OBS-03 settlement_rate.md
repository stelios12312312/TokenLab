---
type: observable_metric
id: "OBS-03"
---
# OBS-03: settlement_rate(t)

**Definition:** G3 volume / ACR_Available(t)
**Measures:** Demand for conversion
