---
type: observable_metric
id: "OBS-07"
---
# OBS-07: utility_consumption(t)

**Definition:** Aggregate G5a(t) volume
**Measures:** Real demand signal
