---
type: observable_metric
id: "OBS-02"
---
# OBS-02: claim_rate(t)

**Definition:** G0 conversions / eligible population
**Measures:** Onboarding health
