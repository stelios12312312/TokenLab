---
type: observable_metric
id: "OBS-14"
---
# OBS-14: campaign_fill_rate(t)

**Definition:** Settled campaigns / total campaigns
**Measures:** External demand health
