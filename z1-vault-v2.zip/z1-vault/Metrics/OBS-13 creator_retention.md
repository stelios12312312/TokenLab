---
type: observable_metric
id: "OBS-13"
---
# OBS-13: creator_retention(t)

**Definition:** Active creators(t) / creators(t-4 epochs)
**Measures:** Supply-side health
