---
type: observable_metric
id: "OBS-08"
---
# OBS-08: burn_rate(t)

**Definition:** delta_Z1U_Burned(t) / Z1U_Circulating(t)
**Measures:** Deflationary pressure
