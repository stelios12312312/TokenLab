---
type: observable_metric
id: "OBS-10"
---
# OBS-10: gini_z1u(t)

**Definition:** Gini coefficient of Z1U distribution
**Measures:** Wealth concentration
