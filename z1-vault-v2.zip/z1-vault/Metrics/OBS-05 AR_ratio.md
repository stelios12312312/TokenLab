---
type: observable_metric
id: "OBS-05"
---
# OBS-05: AR_ratio(t)

**Definition:** AR(t) / Z1U_Circulating(t)
**Measures:** Reserve health
