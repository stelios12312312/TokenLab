---
type: observable_metric
id: "OBS-01"
---
# OBS-01: n1(t)

**Definition:** Active viewer count
**Measures:** Ecosystem scale
