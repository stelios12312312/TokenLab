---
type: gate
id: "G8"
direction: "Brand -> Escrow"
asset: "Z1U"
---
# G8: Campaign Deposit

**Direction:** Brand -> Escrow
**Asset:** Z1U
**State effect:** `delta_CE(t) > 0`

External buyer funds campaign escrow for verified attention services. Terms defined upfront.
