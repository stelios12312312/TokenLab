---
type: gate
id: "G6"
direction: "User -> Staking"
asset: "Z1U"
---
# G6: Governance Stake

**Direction:** User -> Staking
**Asset:** Z1U
**State effect:** `delta_z1u_staked(a,t) > 0`

Time-locked staking for governance power. Requires ACR verification. Min/max duration, caps, anti-capture limits.
