---
type: gate
id: "SYS_throttle"
direction: "System internal"
asset: "-"
---
# SYS_throttle: Treasury Health Feedback

**Direction:** System internal
**Asset:** -
**State effect:** `Reduce PCS weights, extend vesting duration, lower issuance rate`

Fires when treasury_health(t) < theta_min, where treasury_health := T(t) / (G11_demand + G12_demand + G15_demand + G16_demand). Automated sustainability brake.
