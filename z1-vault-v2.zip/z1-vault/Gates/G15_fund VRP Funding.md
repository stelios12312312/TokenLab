---
type: gate
id: "G15_fund"
direction: "Treasury -> VRP"
asset: "Z1U"
---
# G15_fund: VRP Funding

**Direction:** Treasury -> VRP
**Asset:** Z1U
**State effect:** `delta_VRP(t) > 0, delta_T(t) < 0`

Treasury budget action funds Validator Reward Pool. Similar routing to G12. Epoch-based or governance-approved.
