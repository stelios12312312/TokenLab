---
type: gate
id: "G9a"
direction: "Escrow -> Recipients"
asset: "Z1U"
---
# G9a: Campaign Payout

**Direction:** Escrow -> Recipients
**Asset:** Z1U
**State effect:** `delta_CE(t) < 0`

Campaign escrow settles to the audience on verified outcome attestation.
