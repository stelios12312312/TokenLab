---
type: gate
id: "G7"
direction: "User <-> External"
asset: "Z1U"
---
# G7: Transfer - Market

**Direction:** User <-> External
**Asset:** Z1U
**State effect:** `-`

Z1U transferred/traded freely (DEX/CEX/OTC). No programme-level permissioning at transfer layer.
