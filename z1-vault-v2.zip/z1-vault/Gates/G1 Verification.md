---
type: gate
id: "G1"
direction: "System -> User"
asset: "-"
---
# G1: Verification

**Direction:** System -> User
**Asset:** -
**State effect:** `claim_status in {pending, pass, hold, deny}`

One-person-one-claim check. Identity/eligibility/fraud verification. Blocks sybils. Tier A/B/C recorded.
