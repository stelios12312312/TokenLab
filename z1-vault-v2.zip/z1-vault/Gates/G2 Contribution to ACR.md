---
type: gate
id: "G2"
direction: "System -> ACR ledger"
asset: "-"
---
# G2: Contribution to ACR

**Direction:** System -> ACR ledger
**Asset:** -
**State effect:** `delta_acr_issued(a,t) > 0`

PCS scoring of verified participation signals. ACR credits posted as recognition output.
