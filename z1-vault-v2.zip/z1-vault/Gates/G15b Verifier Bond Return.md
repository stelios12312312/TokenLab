---
type: gate
id: "G15b"
direction: "Escrow -> Verifier"
asset: "Z1U"
---
# G15b: Verifier Bond Return

**Direction:** Escrow -> Verifier
**Asset:** Z1U
**State effect:** `-`

Honest Community Verifiers receive bond back plus small reward from VRP. Bond return from escrow, reward from VRP. Attestations must not have been flagged.
