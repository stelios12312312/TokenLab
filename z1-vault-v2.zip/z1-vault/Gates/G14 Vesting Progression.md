---
type: gate
id: "G14"
direction: "ACR ledger internal"
asset: "-"
---
# G14: Vesting Progression

**Direction:** ACR ledger internal
**Asset:** -
**State effect:** `delta_ACR_Vesting < 0, delta_ACR_Available > 0`

Epoch-driven. Cliff then linear unlock. Pauses if claim_status changes to hold. Leading indicator of AR settlement pressure.
