---
type: gate
id: "G13b"
direction: "ACR ledger internal"
asset: "-"
---
# G13b: ACR Voiding

**Direction:** ACR ledger internal
**Asset:** -
**State effect:** `ACR_Held -> ACR_Voided`

Fraud-confirmed ACR transitions from Held to Voided. Reduces future settlement pressure on AR. No Z1U moves.
