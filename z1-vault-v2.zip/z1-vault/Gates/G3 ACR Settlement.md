---
type: gate
id: "G3"
direction: "AR -> User"
asset: "Z1U"
---
# G3: ACR Settlement

**Direction:** AR -> User
**Asset:** Z1U
**State effect:** `delta_AR(t) < 0, delta_z1u_balance(a,t) > 0`

Converts vested ACR into Z1U. Always debits Audience Reserve. Budget-conserving. AR_balance(t) >= AR_floor(t) enforced.
