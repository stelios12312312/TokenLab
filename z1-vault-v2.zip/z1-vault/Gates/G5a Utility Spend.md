---
type: gate
id: "G5a"
direction: "User -> Utility Dest."
asset: "Z1U"
---
# G5a: Utility Spend

**Direction:** User -> Utility Dest.
**Asset:** Z1U
**State effect:** `delta_z1u_balance(a,t) < 0`

Net price of utility SKU flows to destination (content access, features, services).
