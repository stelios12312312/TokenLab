---
type: gate
id: "G11"
direction: "Treasury -> AR"
asset: "Z1U"
---
# G11: AR Top-up

**Direction:** Treasury -> AR
**Asset:** Z1U
**State effect:** `delta_AR(t) > 0, delta_T(t) < 0`

Triggered when AR breaches floor (25% of circulating). Bounded by caps. Treasury must have sufficient budget.
