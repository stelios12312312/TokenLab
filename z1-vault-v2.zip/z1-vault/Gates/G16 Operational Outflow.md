---
type: gate
id: "G16"
direction: "Treasury -> External"
asset: "Z1U"
---
# G16: Operational Outflow

**Direction:** Treasury -> External
**Asset:** Z1U
**State effect:** `delta_T(t) < 0`

Funds ecosystem development, infrastructure, security audits, partnerships, liquidity ops. Governance-approved budget envelope required. Published criteria and audit trail. Cannot be used for AR-eligible purposes (use G11). Cannot be framed as price support.
