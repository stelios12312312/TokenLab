---
type: gate
id: "G13a"
direction: "Staked/Bonded -> Treasury"
asset: "Z1U"
---
# G13a: Z1U Slashing

**Direction:** Staked/Bonded -> Treasury
**Asset:** Z1U
**State effect:** `delta_T(t) > 0, delta_z1u_staked(a,t) < 0`

Slashed Z1U from governance stakes or Community Verifier bonds routes to Treasury. -200% penalty: claws back original + equal penalty from other balances. Due process required (evidence disclosure, 14-day appeal window, independent review).
