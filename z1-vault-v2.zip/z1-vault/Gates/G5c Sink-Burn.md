---
type: gate
id: "G5c"
direction: "User -> Burn"
asset: "Z1U"
---
# G5c: Sink-Burn

**Direction:** User -> Burn
**Asset:** Z1U
**State effect:** `delta_Z1U_Burned(t) > 0`

Optional usage-linked burn.
