---
type: gate
id: "G12"
direction: "Treasury -> CIP"
asset: "Z1U"
---
# G12: CIP Replenish

**Direction:** Treasury -> CIP
**Asset:** Z1U
**State effect:** `delta_CIP(t) > 0, delta_T(t) < 0`

Epoch-based budget routing to fund creator/participation programmes.
