---
type: gate
id: "G17"
direction: "ACR ledger -> Burn/AR"
asset: "-"
---
# G17: ACR Expiry - Breakage

**Direction:** ACR ledger -> Burn/AR
**Asset:** -
**State effect:** `ACR_Available -> ACR_Expired`

24-month dormancy triggers breakage policy. Expired ACR either burns (default) or reflows to AR with governance approval. Reduces outstanding settlement obligations.
