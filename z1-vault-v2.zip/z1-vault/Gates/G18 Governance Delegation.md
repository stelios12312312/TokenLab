---
type: gate
id: "G18"
direction: "User -> Delegate"
asset: "Z1U"
---
# G18: Governance Delegation

**Direction:** User -> Delegate
**Asset:** Z1U
**State effect:** `delta_gov_weight(delegator,t) < 0, delta_gov_weight(delegate,t) > 0`

Transfers governance voting power from delegator to delegate. Both agents must be verified (claim_status = pass). Delegation is revocable. No self-delegation. Delegation depth cap prevents transitive chains.
