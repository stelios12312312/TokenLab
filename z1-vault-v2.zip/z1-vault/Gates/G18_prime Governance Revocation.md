---
type: gate
id: "G18'"
direction: "User -> Delegate"
asset: "Z1U"
---
# G18': Governance Revocation

**Direction:** User -> Delegate
**Asset:** Z1U
**State effect:** `delta_delegated_weight(d,t) < 0, delta_delegations_out(a,t) < 0`

Delegator revokes previously delegated governance power. Effective voting weight returns to delegator. Cooldown period enforced if delegate has active votes in open proposals.
