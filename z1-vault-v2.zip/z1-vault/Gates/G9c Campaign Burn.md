---
type: gate
id: "G9c"
direction: "Escrow -> Burn"
asset: "Z1U"
---
# G9c: Campaign Burn

**Direction:** Escrow -> Burn
**Asset:** Z1U
**State effect:** `delta_Z1U_Burned(t) > 0`

Optional burn on campaign settlements.
