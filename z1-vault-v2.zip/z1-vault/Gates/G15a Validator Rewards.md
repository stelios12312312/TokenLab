---
type: gate
id: "G15a"
direction: "VRP -> Validators"
asset: "Z1U"
---
# G15a: Validator Rewards

**Direction:** VRP -> Validators
**Asset:** Z1U
**State effect:** `delta_VRP(t) < 0`

Pays protocol validators for attestation work. Reward computed on attestation volume, uptime, fraud-catch efficacy. Performance thresholds required.
