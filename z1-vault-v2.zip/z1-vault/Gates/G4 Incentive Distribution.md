---
type: gate
id: "G4"
direction: "CIP -> Recipient"
asset: "Z1U"
---
# G4: Incentive Distribution

**Direction:** CIP -> Recipient
**Asset:** Z1U
**State effect:** `delta_CIP(t) < 0, delta_z1u_balance(a,t) > 0`

Credits Z1U for programme-approved outcomes.
