---
type: gate
id: "G6'"
direction: "Staking -> User"
asset: "Z1U"
---
# G6': Governance Unlock

**Direction:** Staking -> User
**Asset:** Z1U
**State effect:** `delta_z1u_staked(a,t) < 0, delta_z1u_balance(a,t) > 0`

Lock period expires, Z1U returns to circulating balance. Governance weight zeroed on unlock. Early exit penalty (if permitted) routes to Treasury.
