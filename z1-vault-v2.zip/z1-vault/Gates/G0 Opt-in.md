---
type: gate
id: "G0"
direction: "User -> System"
asset: "-"
---
# G0: Opt-in

**Direction:** User -> System
**Asset:** -
**State effect:** `consent_record`

User clicks Join. Creates audit trail of voluntary participation. No tokens move.
