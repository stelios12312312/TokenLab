---
type: gate
id: "G10"
direction: "RWA -> Treasury"
asset: "Fiat->Z1U"
---
# G10: RWA Fee Route

**Direction:** RWA -> Treasury
**Asset:** Fiat->Z1U
**State effect:** `delta_T(t) > 0`

If RWA fees support programmes, they route to the Treasury first. Never directly to users.
