---
type: gate
id: "G5b"
direction: "User -> Treasury"
asset: "Z1U"
---
# G5b: Protocol Fee

**Direction:** User -> Treasury
**Asset:** Z1U
**State effect:** `delta_T(t) > 0`

Fee slice on utility spends routes to Treasury.
