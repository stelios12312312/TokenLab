---
type: gate
id: "G9b"
direction: "Escrow -> Treasury"
asset: "Z1U"
---
# G9b: Campaign Fee

**Direction:** Escrow -> Treasury
**Asset:** Z1U
**State effect:** `delta_T(t) > 0`

Fee slice on campaign settlement routes to Treasury.
