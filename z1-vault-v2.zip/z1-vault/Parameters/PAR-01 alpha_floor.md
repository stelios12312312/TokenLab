---
type: parameter
id: "PAR-01"
tier: "Tier 0"
value: ">= 0.25"
---
# PAR-01: alpha_floor

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `>= 0.25`

AR floor ratio. Minimum AR / Z1U_Circulating. Breach triggers [[G11 AR Top-up]]
