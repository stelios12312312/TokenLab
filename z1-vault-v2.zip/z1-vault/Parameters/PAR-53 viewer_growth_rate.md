---
type: parameter
id: "PAR-53"
tier: "Simulation"
value: "per epoch"
---
# PAR-53: viewer_growth_rate

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `per epoch`

Adoption curve. Feeds [[EXO-01 User adoption rate]]
