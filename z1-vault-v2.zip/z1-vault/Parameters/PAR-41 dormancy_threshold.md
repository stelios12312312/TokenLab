---
type: parameter
id: "PAR-41"
tier: "Tier 1"
value: "24 months"
---
# PAR-41: dormancy_threshold

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `24 months`

Inactivity period before [[G17 ACR Expiry - Breakage]] triggers
