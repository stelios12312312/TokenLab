---
type: parameter
id: "PAR-03"
tier: "Tier 0"
value: "AR=30%, CIP=20%, Treasury=15%, EcoDev=20%, LiqOps=5%, StratPart=2%, Team=8%"
---
# PAR-03: bucket_allocations

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `AR=30%, CIP=20%, Treasury=15%, EcoDev=20%, LiqOps=5%, StratPart=2%, Team=8%`

Genesis vault allocations. Set once at t=0
