---
type: parameter
id: "PAR-15"
tier: "Tier 1"
value: "[0.1, 0.4]"
---
# PAR-15: pcs_weight_referral

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `[0.1, 0.4]`

PCS referral weight w_r. Constraint: w_t + w_q + w_d + w_r = 1.0
