---
type: parameter
id: "PAR-09"
tier: "Tier 0"
value: "AR only"
---
# PAR-09: settlement_source_constraint

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `AR only`

Settlement must always debit Audience Reserve
