---
type: parameter
id: "PAR-64"
tier: "Simulation"
value: "mean Z1U"
---
# PAR-64: brand_avg_budget

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `mean Z1U`

Average campaign budget per A10 brand
