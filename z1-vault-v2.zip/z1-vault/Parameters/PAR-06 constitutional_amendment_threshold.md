---
type: parameter
id: "PAR-06"
tier: "Tier 0"
value: "90% + Trustee"
---
# PAR-06: constitutional_amendment_threshold

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `90% + Trustee`

For any Tier 0 parameter change
