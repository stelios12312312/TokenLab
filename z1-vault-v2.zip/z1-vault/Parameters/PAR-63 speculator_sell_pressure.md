---
type: parameter
id: "PAR-63"
tier: "Simulation"
value: "per epoch"
---
# PAR-63: speculator_sell_pressure

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `per epoch`

A12 sell propensity on external markets
