---
type: parameter
id: "PAR-38"
tier: "Tier 1"
value: "TBD"
---
# PAR-38: verifier_bond_min

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

A7 integrity collateral baseline
