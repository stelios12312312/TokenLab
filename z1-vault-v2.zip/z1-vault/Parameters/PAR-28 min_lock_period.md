---
type: parameter
id: "PAR-28"
tier: "Tier 1"
value: "TBD"
---
# PAR-28: min_lock_period

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Minimum duration for [[G6 Governance Stake]]. Anti-flash-governance
