---
type: parameter
id: "PAR-59"
tier: "Simulation"
value: "%"
---
# PAR-59: adversary_fraction

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `%`

Agents with adversarial_mode = true (A13 flag)
