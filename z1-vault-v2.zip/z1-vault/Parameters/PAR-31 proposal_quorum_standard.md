---
type: parameter
id: "PAR-31"
tier: "Tier 1"
value: "TBD"
---
# PAR-31: proposal_quorum_standard

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Min weight for standard vote validity
