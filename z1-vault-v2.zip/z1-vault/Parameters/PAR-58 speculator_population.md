---
type: parameter
id: "PAR-58"
tier: "Simulation"
value: "count"
---
# PAR-58: speculator_population

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `count`

A12 count on external markets
