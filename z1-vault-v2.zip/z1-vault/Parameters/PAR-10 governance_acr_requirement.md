---
type: parameter
id: "PAR-10"
tier: "Tier 0"
value: "true"
---
# PAR-10: governance_acr_requirement

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `true`

Z1U alone cannot grant governance power
