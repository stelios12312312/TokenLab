---
type: parameter
id: "PAR-65"
tier: "Simulation"
value: "Boolean"
---
# PAR-65: ir_active

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `Boolean`

A8 Independent Reviewer scenario switch
