---
type: parameter
id: "PAR-43"
tier: "Tier 1"
value: "TBD epochs"
---
# PAR-43: revocation_cooldown

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD epochs`

Cooldown before [[G18' Governance Revocation]] takes effect if delegate has active votes
