---
type: parameter
id: "PAR-34"
tier: "Tier 1"
value: "48h standard, 7d reserve"
---
# PAR-34: proposal_timelock

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `48h standard, 7d reserve`

Delay between pass and execution
