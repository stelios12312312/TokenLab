---
type: parameter
id: "PAR-52"
tier: "Simulation"
value: "200M/500M/750M/1B"
---
# PAR-52: initial_viewer_count

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `200M/500M/750M/1B`

Starting A1 population
