---
type: parameter
id: "PAR-12"
tier: "Tier 1"
value: "[0.1, 0.4]"
---
# PAR-12: pcs_weight_tenure

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `[0.1, 0.4]`

PCS tenure weight w_t
