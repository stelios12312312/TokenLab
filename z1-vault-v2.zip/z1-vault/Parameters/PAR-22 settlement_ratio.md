---
type: parameter
id: "PAR-22"
tier: "Tier 1"
value: "TBD: fixed/dynamic/governed"
---
# PAR-22: settlement_ratio

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD: fixed/dynamic/governed`

Biggest open question. ACR to Z1U conversion rate
