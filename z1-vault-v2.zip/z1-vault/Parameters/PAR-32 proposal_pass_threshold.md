---
type: parameter
id: "PAR-32"
tier: "Tier 1"
value: "50%+1"
---
# PAR-32: proposal_pass_threshold

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `50%+1`

For-votes percentage for standard proposals
