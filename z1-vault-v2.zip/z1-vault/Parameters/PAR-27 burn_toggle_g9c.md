---
type: parameter
id: "PAR-27"
tier: "Tier 1"
value: "on/off"
---
# PAR-27: burn_toggle_g9c

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `on/off`

Whether campaign settlements include a burn component via [[G9c Campaign Burn]]
