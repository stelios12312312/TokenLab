---
type: parameter
id: "PAR-18"
tier: "Tier 1"
value: "420 months"
---
# PAR-18: tenure_max

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `420 months`

Tenure saturation per Yellow Paper
