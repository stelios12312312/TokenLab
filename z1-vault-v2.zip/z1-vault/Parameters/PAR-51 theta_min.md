---
type: parameter
id: "PAR-51"
tier: "Tier 2"
value: "TBD"
---
# PAR-51: theta_min

**Tier:** Tier 2 - Operational. Set by A6 operator within approved budgets
**Value/Range:** `TBD`

Treasury health threshold for [[SYS_throttle Treasury Health Feedback]]
