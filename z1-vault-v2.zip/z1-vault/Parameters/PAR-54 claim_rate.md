---
type: parameter
id: "PAR-54"
tier: "Simulation"
value: "20%/50%/80%"
---
# PAR-54: claim_rate

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `20%/50%/80%`

Percent of eligible who actually claim via [[G0 Opt-in]]
