---
type: parameter
id: "PAR-56"
tier: "Simulation"
value: "%"
---
# PAR-56: scout_ratio

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `%`

A1 to A3 upgrade rate
