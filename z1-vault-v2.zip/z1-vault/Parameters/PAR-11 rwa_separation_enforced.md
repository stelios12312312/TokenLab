---
type: parameter
id: "PAR-11"
tier: "Tier 0"
value: "true"
---
# PAR-11: rwa_separation_enforced

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `true`

RWA returns stay in RWA instrument. No Z1U conversion
