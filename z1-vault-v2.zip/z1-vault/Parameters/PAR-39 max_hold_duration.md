---
type: parameter
id: "PAR-39"
tier: "Tier 1"
value: "TBD epochs"
---
# PAR-39: max_hold_duration

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD epochs`

Mandatory hold resolution deadline. Prevents indefinite freeze
