---
type: parameter
id: "PAR-42"
tier: "Tier 1"
value: "TBD"
---
# PAR-42: delegation_depth_max

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Maximum transitive delegation chain length for [[G18 Governance Delegation]]
