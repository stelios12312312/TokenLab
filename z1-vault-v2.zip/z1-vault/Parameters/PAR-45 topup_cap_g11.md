---
type: parameter
id: "PAR-45"
tier: "Tier 1"
value: "TBD"
---
# PAR-45: topup_cap_g11

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Bounded Treasury to AR transfer per trigger via [[G11 AR Top-up]]
