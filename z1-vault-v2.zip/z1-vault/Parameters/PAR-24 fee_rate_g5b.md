---
type: parameter
id: "PAR-24"
tier: "Tier 1"
value: "TBD"
---
# PAR-24: fee_rate_g5b

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Treasury capture on utility transactions via [[G5b Protocol Fee]]
