---
type: parameter
id: "PAR-04"
tier: "Tier 0"
value: "90%"
---
# PAR-04: inflation_governance_threshold

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `90%`

Vote weight required to approve minting above cap
