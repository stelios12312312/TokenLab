---
type: parameter
id: "PAR-46"
tier: "Tier 1"
value: "TBD"
---
# PAR-46: vrp_budget_epoch

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Z1U allocated to validators per epoch via [[G15_fund VRP Funding]]
