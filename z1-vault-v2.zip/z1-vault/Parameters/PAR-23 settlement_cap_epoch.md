---
type: parameter
id: "PAR-23"
tier: "Tier 1"
value: "TBD"
---
# PAR-23: settlement_cap_epoch

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Max settlement per epoch. Rate limiter on [[G3 ACR Settlement]] outflows
