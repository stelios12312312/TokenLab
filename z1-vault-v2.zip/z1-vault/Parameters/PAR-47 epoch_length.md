---
type: parameter
id: "PAR-47"
tier: "Tier 2"
value: "TBD (weekly baseline)"
---
# PAR-47: epoch_length

**Tier:** Tier 2 - Operational. Set by A6 operator within approved budgets
**Value/Range:** `TBD (weekly baseline)`

Time granularity for batch operations
