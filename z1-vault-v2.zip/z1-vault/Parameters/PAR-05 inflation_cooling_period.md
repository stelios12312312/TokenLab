---
type: parameter
id: "PAR-05"
tier: "Tier 0"
value: "60 days"
---
# PAR-05: inflation_cooling_period

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `60 days`

Mandatory wait after inflation vote passes
