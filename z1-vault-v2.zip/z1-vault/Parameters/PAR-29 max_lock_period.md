---
type: parameter
id: "PAR-29"
tier: "Tier 1"
value: "TBD"
---
# PAR-29: max_lock_period

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Maximum duration for governance staking
