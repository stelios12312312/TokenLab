---
type: parameter
id: "PAR-07"
tier: "Tier 0"
value: "30-60 days"
---
# PAR-07: constitutional_cooling_period

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `30-60 days`

Mandatory wait after constitutional amendment
