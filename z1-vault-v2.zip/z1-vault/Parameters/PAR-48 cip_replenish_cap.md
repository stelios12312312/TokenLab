---
type: parameter
id: "PAR-48"
tier: "Tier 2"
value: "TBD"
---
# PAR-48: cip_replenish_cap

**Tier:** Tier 2 - Operational. Set by A6 operator within approved budgets
**Value/Range:** `TBD`

Max CIP replenish per epoch via [[G12 CIP Replenish]]
