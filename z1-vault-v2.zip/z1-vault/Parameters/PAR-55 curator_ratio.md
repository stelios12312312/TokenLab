---
type: parameter
id: "PAR-55"
tier: "Simulation"
value: "%"
---
# PAR-55: curator_ratio

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `%`

A1 to A2 upgrade rate
