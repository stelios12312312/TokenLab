---
type: parameter
id: "PAR-37"
tier: "Tier 1"
value: "120 days"
---
# PAR-37: producer_lock_duration

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `120 days`

Producer stake lock period
