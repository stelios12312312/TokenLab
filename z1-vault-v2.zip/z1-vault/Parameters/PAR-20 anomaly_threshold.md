---
type: parameter
id: "PAR-20"
tier: "Tier 1"
value: "gamma threshold"
---
# PAR-20: anomaly_threshold

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `gamma threshold`

Below this anomaly score triggers auto-hold
