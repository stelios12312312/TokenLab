---
type: parameter
id: "PAR-14"
tier: "Tier 1"
value: "[0.1, 0.4]"
---
# PAR-14: pcs_weight_diversity

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `[0.1, 0.4]`

PCS diversity weight w_d
