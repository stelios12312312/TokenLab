---
type: parameter
id: "PAR-50"
tier: "Tier 2"
value: "TBD"
---
# PAR-50: campaign_min_budget

**Tier:** Tier 2 - Operational. Set by A6 operator within approved budgets
**Value/Range:** `TBD`

Campaign quality floor for [[G8 Campaign Deposit]]
