---
type: parameter
id: "PAR-16"
tier: "Tier 1"
value: "alpha"
---
# PAR-16: pcs_floor_alpha

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `alpha`

Per-epoch minimum PCS score
