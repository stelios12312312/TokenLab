---
type: parameter
id: "PAR-02"
tier: "Tier 0"
value: "10^12 (1T)"
---
# PAR-02: Z1U_TotalCap

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `10^12 (1T)`

Hard supply ceiling. Maximum Z1U ever mintable
