---
type: parameter
id: "PAR-66"
tier: "Simulation"
value: "Boolean"
---
# PAR-66: trustee_active

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `Boolean`

A9 Trustee scenario switch
