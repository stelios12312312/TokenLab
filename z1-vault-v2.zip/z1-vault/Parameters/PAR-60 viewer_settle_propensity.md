---
type: parameter
id: "PAR-60"
tier: "Simulation"
value: "probability"
---
# PAR-60: viewer_settle_propensity

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `probability`

[[G3 ACR Settlement]] trigger probability per epoch. High sensitivity
