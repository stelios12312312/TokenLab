---
type: parameter
id: "PAR-25"
tier: "Tier 1"
value: "TBD"
---
# PAR-25: fee_rate_g9b

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Treasury capture on campaign settlements via [[G9b Campaign Fee]]
