---
type: parameter
id: "PAR-08"
tier: "Tier 0"
value: "true (enforced)"
---
# PAR-08: acr_non_transferability

**Tier:** Tier 0 - Constitutional. 90% supermajority + Trustee + 60d cooling to change
**Value/Range:** `true (enforced)`

ACR is soulbound. No transfers, no markets
