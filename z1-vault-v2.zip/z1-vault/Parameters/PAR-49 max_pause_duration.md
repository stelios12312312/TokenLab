---
type: parameter
id: "PAR-49"
tier: "Tier 2"
value: "TBD epochs"
---
# PAR-49: max_pause_duration

**Tier:** Tier 2 - Operational. Set by A6 operator within approved budgets
**Value/Range:** `TBD epochs`

Auto-unpause limit for emergency circuit breaker
