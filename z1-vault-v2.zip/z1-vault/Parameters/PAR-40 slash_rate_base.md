---
type: parameter
id: "PAR-40"
tier: "Tier 1"
value: "TBD %"
---
# PAR-40: slash_rate_base

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD %`

First offense rate. Escalating. ACR fraud: -200%
