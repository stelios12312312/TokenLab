---
type: parameter
id: "PAR-17"
tier: "Tier 1"
value: "beta"
---
# PAR-17: pcs_cap_beta

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `beta`

Per-epoch maximum PCS score
