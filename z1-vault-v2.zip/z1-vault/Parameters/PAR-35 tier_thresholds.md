---
type: parameter
id: "PAR-35"
tier: "Tier 1"
value: "TBD"
---
# PAR-35: tier_thresholds

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Z1U balance requirements for Bronze/Silver/Gold/Platinum access tiers
