---
type: parameter
id: "PAR-62"
tier: "Simulation"
value: "%"
---
# PAR-62: viewer_gov_participation

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `%`

[[G6 Governance Stake]] activation rate
