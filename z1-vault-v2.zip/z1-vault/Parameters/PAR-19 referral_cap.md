---
type: parameter
id: "PAR-19"
tier: "Tier 1"
value: "R_CAP"
---
# PAR-19: referral_cap

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `R_CAP`

Diminishing returns on referral graph position
