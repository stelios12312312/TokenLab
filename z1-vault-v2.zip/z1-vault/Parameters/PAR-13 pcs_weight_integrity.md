---
type: parameter
id: "PAR-13"
tier: "Tier 1"
value: "[0.1, 0.4]"
---
# PAR-13: pcs_weight_integrity

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `[0.1, 0.4]`

PCS integrity weight w_q
