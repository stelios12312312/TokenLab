---
type: parameter
id: "PAR-44"
tier: "Tier 1"
value: "TBD"
---
# PAR-44: sku_prices

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

Utility SKU pricing. USD-denominated per DOC-019; Z1U quantity adjusts via internal reference rate
