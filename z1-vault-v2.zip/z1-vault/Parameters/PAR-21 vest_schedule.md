---
type: parameter
id: "PAR-21"
tier: "Tier 1"
value: "TBD"
---
# PAR-21: vest_schedule

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

ACR vesting curve. Rate at which ACR transitions Vesting to Available. From DOC-013 parameter registry
