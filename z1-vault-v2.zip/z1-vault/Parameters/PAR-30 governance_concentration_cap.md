---
type: parameter
id: "PAR-30"
tier: "Tier 1"
value: "max %"
---
# PAR-30: governance_concentration_cap

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `max %`

Max individual governance weight share
