---
type: parameter
id: "PAR-33"
tier: "Tier 1"
value: "TBD epochs"
---
# PAR-33: proposal_voting_period

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD epochs`

Voting window duration
