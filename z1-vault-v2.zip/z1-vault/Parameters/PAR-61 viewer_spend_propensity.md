---
type: parameter
id: "PAR-61"
tier: "Simulation"
value: "probability"
---
# PAR-61: viewer_spend_propensity

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `probability`

[[G5a Utility Spend]] probability per epoch
