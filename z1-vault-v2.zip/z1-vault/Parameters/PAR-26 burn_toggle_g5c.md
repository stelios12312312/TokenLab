---
type: parameter
id: "PAR-26"
tier: "Tier 1"
value: "on/off"
---
# PAR-26: burn_toggle_g5c

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `on/off`

Whether utility spends include a burn component via [[G5c Sink-Burn]]
