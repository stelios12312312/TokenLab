---
type: parameter
id: "PAR-36"
tier: "Tier 1"
value: "TBD"
---
# PAR-36: producer_stake_min

**Tier:** Tier 1 - Governed. Standard vote within bounded ranges
**Value/Range:** `TBD`

A5 greenlight proposal gate
