---
type: parameter
id: "PAR-57"
tier: "Simulation"
value: "per epoch"
---
# PAR-57: brand_entry_rate

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `per epoch`

New A10 brands entering via [[G8 Campaign Deposit]]
