---
type: parameter
id: "PAR-67"
tier: "Simulation"
value: "probability"
---
# PAR-67: hold_resolution_rate

**Tier:** Simulation - ABM configuration. Not on-chain. Scenario inputs for Dr. Kampakis
**Value/Range:** `probability`

Held agent resolution per epoch
