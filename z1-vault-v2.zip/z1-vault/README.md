---
type: readme
---
# Z1 MSML Specification Vault

Complete token engineering specification for the Z1 dual-economy protocol.
Built by Provecto Labs (Phase 2, Track A) following the BlockScience / Vasily Sumanov TE framework.

## What is this?

This Obsidian vault is the mathematical specification for the Z1 token economy. It describes every moving part: what exists, what state it carries, how actions flow through the system, what logic governs decisions, and how everything composes into a single execution pipeline per timestep.

The vault is the authoritative source of truth for what gets simulated in Phase 3 (cadCAD + TokenLab with Dr. Kampakis). It sits between the design documents (DOC-001 through DOC-019) and the simulation code.

## How to read this vault

### Start here

1. Open Graph View (Ctrl/Cmd + G). Colors = building block types. Most connected nodes = structural hubs.
2. Read the Entities folder first (7 types that define what exists).
3. Read the Gates folder (28 gates that define all state transitions).
4. Read the [[Epoch Pipeline]] note in Wirings (how one timestep executes start to finish).

### Building blocks (in dependency order)

**Step 1: Entities + State + Types** (the foundation)
- Entity = a type of thing that carries state (7 types: Global, ACR Ledger, Z1U Token Ledger, Agent, Pool, Escrow, Governance Proposal)
- State = every variable an entity instance carries
- Type = custom type definitions referenced by state variables

**Step 2: Gates** (the atomic operations)
- Gate = a guarded state transition. Fires only when preconditions are met. 28 gates from DOC-013 section 3.1 plus SYS_throttle.
- Organized by: Audience Pipeline, Z1U Utility Economy, Campaign/A2E, Integrity/Slashing, Validator/Verifier Rewards, Treasury Operations, ACR Lifecycle, Gov Delegation

**Step 3: Spaces** (the data shapes)
- Space = a typed data structure that flows between components. 24 spaces in 6 groups.
- Most reused: S03 EligibilityCheck (compliance spine), S09 Z1UTransfer (universal transfer), S11 BurnEvent (all sinks), S22 TreasuryRouting (monetary policy)

**Step 4: Mechanisms** (the state writes)
- Mechanism = atomic state write. Terminal block. 57 mechanisms organized by target entity.
- Most connected: M15 Transfer Z1U (every flow routes through it)

**Step 5: Policies** (the decision logic)
- Policy = intelligence between actions and mechanisms. Domain + codomain + logic. 44 policies in 10 groups.
- Most called: P02 Eligibility revalidation (every benefit gate). Highest uncertainty: P11 Settlement ratio.

**Step 6: Parameters** (the configurable values)
- Tier 0 (Constitutional): 11 params. 90% + Trustee + 60d cooling.
- Tier 1 (Governed): 35 params. Standard vote within bounded ranges.
- Tier 2 (Operational): 5 params. Operator-set within budgets.
- Simulation-only: 16 params. ABM scenario inputs.

**Step 7: Actions** (the triggers)
- Boundary Action = agent-initiated (12 actions)
- Control Action = system-initiated per epoch (9 actions)

**Step 8: Wirings** (the execution pipelines)
- Wiring = composed pipeline of actions + policies + mechanisms. 26 wirings in 3 phases.
- Phase 1 (CW-01 to CW-09): System updates, strict order
- Phase 2+3 (BW-01 to BW-13): Agent actions, parallelizable
- Phase 4 (AW-01 to AW-04): Accounting and invariant checks

### Also included

- **Gates**: 29 notes (all 28 from DOC-013 section 3.1 + SYS_throttle) with preconditions, state effects, and descriptions
- **Observable Metrics**: 15 KPIs from DOC-013 section 5 (OBS-01 to OBS-15)
- **Exogenous Variables**: 9 boundary inputs from DOC-013 section 8 (EXO-01 to EXO-09)
- **Cross-Entity Invariants**: conservation laws, floor constraints, anti-capture rules

## The dual economy in one paragraph

Z1 has two economies connected by one bridge. The recognition economy (ACR, soulbound, non-transferable) tracks verified audience participation via the PCS scoring algorithm for agents A1-A5. The utility economy (Z1U, transferable, ERC-20) is the token people hold, spend, govern with, and trade. The bridge is [[G3 ACR Settlement]]: acr_available converts to Z1U, debiting the Audience Reserve pool. The system's sustainability depends on whether AR can fund settlements long-term, which is why settlement_pressure_ratio (ACR_Available / AR_balance) is the single most important metric.

## Agents (A1-A14)

See [[Agent Registry]] for the complete table with partitions, constraints, and simulation status.

## Inventory

| Building block | Count |
|---------------|-------|
| Entities | 7 + Agent Registry |
| State definitions | 7 |
| Types | 39 |
| Gates | 29 |
| Spaces | 24 |
| Mechanisms | 57 |
| Policies | 44 |
| Parameters | 67 |
| Boundary Actions | 12 |
| Control Actions | 9 |
| Wirings | 27 (incl. Epoch Pipeline) |
| Observable Metrics | 15 |
| Exogenous Variables | 9 |
| Cross-Entity Invariants | 1 |

## What comes next

Phase 3: Simulation and Stress Testing (cadCAD + TokenLab, Dr. Stylianos Kampakis). The 6 highest-sensitivity parameters:
- PAR-22 (settlement ratio): single biggest impact on emission and AR depletion
- PAR-21 (vesting schedule): controls when settlement pressure materializes
- PAR-01 (alpha_floor): AR floor threshold, drives G11 trigger frequency
- PAR-24 (fee_rate_g5b): primary treasury revenue, affects velocity
- PAR-54 (claim_rate): how much AR gets consumed and how fast
- PAR-60 (viewer_settle_propensity): settlement pressure timing distribution

---
Provecto Labs x Z1 - Phase 2 Track A - Token Engineering Specification
Built March 2026
