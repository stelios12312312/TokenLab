---
type: entity
id: "E2"
lifecycle: "Singleton"
---
# E2: ACR Ledger

On-chain soulbound smart contract. Authority for all ACR state. Per-user indexed: 6 ACR lifecycle states + PCS + tier + claim status + dormancy. System aggregates: settlement pressure. Non-transferable. Recognition economy authority. A_ACR := {A1, A2, A3, A4, A5} (all agent types that earn ACR).

## State
See [[ACR Ledger State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
