---
type: entity
id: "E7"
lifecycle: "Dynamic (created per submission, resolved or expired)"
---
# E7: Governance Proposal

Per-proposal lifecycle entity. Types: parameter_change, greenlight_vote, constitutional_amendment, budget_allocation. Lifecycle: proposed -> voting -> passed/rejected/expired -> cooling (if constitutional) -> executed.

## State
See [[Governance Proposal State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
