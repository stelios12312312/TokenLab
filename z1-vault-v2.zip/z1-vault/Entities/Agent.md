---
type: entity
id: "E4"
lifecycle: "Dynamic (created via [[G0 Opt-in]], deactivated via ban/exit)"
---
# E4: Agent

All 14 actor types. Single entity discriminated by agent_type field. See [[Agent Registry]] for full A1-A14 table.

## State
See [[Agent State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
