---
type: entity
id: "E1"
lifecycle: "Singleton"
---
# E1: Global

Protocol world state. Epoch clock, Z1U supply aggregates, inflation gate, market exogenous inputs, burn counter. Genesis mint is the initial condition at t=0.

## State
See [[Global State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
