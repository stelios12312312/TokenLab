---
type: entity
id: "E6"
lifecycle: "Dynamic (created on deposit, destroyed on settlement/cancellation)"
---
# E6: Escrow

Dynamic Z1U containers. Three subtypes: Campaign (funded by A10 via [[G8 Campaign Deposit]]), Production (greenlight-funded, milestone-gated), Prediction (stake then redistribute).

## State
See [[Escrow State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
