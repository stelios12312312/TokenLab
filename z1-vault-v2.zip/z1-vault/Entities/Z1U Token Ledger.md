---
type: entity
id: "E3"
lifecycle: "Singleton"
---
# E3: Z1U Token Ledger

On-chain ERC-20 token contract. Master authority for all Z1U balances. Per-address balance mapping. [[Agent]], [[Pool]], [[Escrow]] balances are views into this ledger. Utility economy authority.

## State
See [[Z1U Token Ledger State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
