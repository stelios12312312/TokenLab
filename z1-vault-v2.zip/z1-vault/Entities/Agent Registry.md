---
type: reference
---
# Agent Registry (A1-A14)

A := {A1, A2, ..., A14} (14 distinct agent types)

## Agent partitions (from DOC-013 section 1.3)

AUDIENCE_ECONOMY := {A1, A2, A3, A4, A5}
(participation-side: earn ACR, spend/earn Z1U via programme rules)

SYSTEM_AGENTS := {A6, A7, A8, A9, A14}
(infrastructure: enforce rules, verify, govern, resolve disputes)

CAPITAL_AGENTS := {A10, A11}
(demand-side: inject external value in exchange for access/assets)

EXTERNAL_AGENTS := {A12, A13}
(outside boundary: no programme benefits, adversarial or neutral)

## ACR-earning agents

A_ACR := {A1, A2, A3, A4, A5}
(all types that earn ACR via [[G2 Contribution to ACR]])

## Complete registry

| ID | Type | Symbol | Primary value | Asset relation | Objective |
|----|------|--------|--------------|---------------|-----------|
| A1 | Viewer | V | Attention, engagement, governance votes, consented data | ACR (earned, non-transferable) -> Z1U | Maximize utility received per unit attention. Minimize effort |
| A2 | Curator | C | Quality signal filtering, list curation, endorsements | ACR (earned, non-transferable) -> Z1U | Maximize reputation/influence. Signal quality recognition |
| A3 | Scout | S | Talent discovery, referral graphs, new project signals | ACR (earned, non-transferable) -> Z1U | Maximize bounty payouts. Build a discovery reputation |
| A4 | Creator | CR | Content production, IP, community engagement, milestone delivery | ACR (earned, non-transferable) -> Z1U | Maximize funding access + audience reach. Deliver milestones |
| A5 | Studio | ST | Production capacity, professional delivery, investment vehicles | Z1U | Maximize greenlight probability. Deliver funded productions |
| A6 | Operator | OP | Platform operation, tooling, policy enforcement, analytics | N/A (system agent) | Maximize ecosystem health metrics. Enforce programme rules |
| A7 | Validator | VL | Identity attestations, integrity proofs, anti-sybil checks | ACR (earned, non-transferable) -> Z1U | Maximize attestation accuracy. Minimize false positives/negatives |
| A8 | Ind. Reviewer | IR | Dispute resolution, procedural justice, corrections | N/A (system agent) | Maximize procedural fairness. Resolve disputes impartially |
| A9 | Trustee | TR | Oversight, Protected Provisions enforcement, compliance reporting | N/A (system agent) | Preserve credibility of protections. Prevent arbitrary operator behavior |
| A10 | Brand | BR | Campaign budgets, sponsorship, A2E API demand | Transferable (Z1U buyer) | Maximize verified attention per unit spend. Access compliant campaign analytics |
| A11 | RWA Investor | RI | Patient capital for content assets (ring-fenced) | Ring-fenced instrument | Maximize risk-adjusted return on content financing |
| A12 | Ext. Speculator | ES | Liquidity on external markets (unintended) | Transferable (Z1U holder) | Maximize trading profit. No programme benefits |
| A13 | Adversary | AD | N/A (attack surface exploitation) | Any obtainable | Maximize extraction. Minimize detection probability |
| A14 | Gov. Delegate | GD | Delegated voting power, community representation | Non-transferable (delegated) | Represent constituent interests. Maintain delegation trust |

## Population constraints (from DOC-013 section 1.4)

- C1: one-person-one-claim for A1 (Sybil constraint)
- C2: n1(t) <= N_max where N_max ~ 10^9 (target scale)
- C3: A12 agents have no on-platform identity (no programme benefits, no governance rights)
- C4: A13 agents are adversarial by definition (system goal: make pi_13 < 0)

## Simulation status

| ID | Sim status | Notes |
|----|-----------|-------|
| A1-A5 | Simulatable | Full agent-based modeling |
| A6 | Simulatable | System agent with policy actions |
| A7 | Simulatable | Validator with bond + attestation |
| A8 | Scenario switch | No economic decision function (PAR-70) |
| A9 | Scenario switch | No economic decision function (PAR-71) |
| A10 | Simulatable | Brand entry/exit + campaign behavior |
| A11 | Simulatable | RWA positions + compliance status |
| A12 | Simulatable | Hold/trade on external markets |
| A13 | Behavioral mode flag | adversarial_mode on other agent instances |
| A14 | Simulatable | Delegated voting behavior |
