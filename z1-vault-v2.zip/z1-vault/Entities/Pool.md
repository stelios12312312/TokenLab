---
type: entity
id: "E5"
lifecycle: "Static (created at genesis)"
---
# E5: Pool

All Z1U holding containers: 7 bucket vaults (time-locked) + operational pools (AR, CIP, Treasury, EcoDev, LiqOps, VRP). VRP is the Validator Reward Pool funded via [[G15_fund VRP Funding]].

## State
See [[Pool State]]

## Boundary conditions (not entities)
- External markets: Z1U exits via [[G7 Transfer - Market]]. Price/volume feed into [[Global]] as exogenous
- RWA instruments: ring-fenced. Only touchpoint: [[G10 RWA Fee Route]] fees to Treasury
- Genesis mint: t=0 event populating all 7 vaults per allocation %
- A2E API burn: external buy then burn, pure deflationary sink
