---
type: policy
id: "P09"
group: "Scoring"
---
# P09: Curation-scout reward

A2 accuracy rewards + A3 bounty eligibility from CIP.

## Domain
Curation outcomes, referral data

## Codomain
reward amount, bounty stage

## Fires
[[M38 Update curation-scout metrics]]
