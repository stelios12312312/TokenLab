---
type: policy
id: "P41"
group: "System"
---
# P41: Emergency pause

Circuit breaker decision.

## Domain
Trigger event

## Codomain
pause (bool)

## Fires
[[M18 Toggle pause]]. Time-limited.
