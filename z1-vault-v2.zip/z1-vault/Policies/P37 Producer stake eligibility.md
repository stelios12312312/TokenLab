---
type: policy
id: "P37"
group: "Staking"
---
# P37: Producer stake eligibility

A5 studio wants to lock for greenlight.

## Domain
agent_id, amount

## Codomain
eligible

## Fires
[[M30 Producer stake lock]]
