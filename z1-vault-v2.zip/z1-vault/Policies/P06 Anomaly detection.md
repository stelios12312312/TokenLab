---
type: policy
id: "P06"
group: "Scoring"
---
# P06: Anomaly detection

ML-based fraud/bot detection. Sub-policy called within P05.

## Domain
Behavioral signals

## Codomain
anomaly_score gamma in [0,1]

## Fires
If gamma < threshold then integrity_flag triggers hold
