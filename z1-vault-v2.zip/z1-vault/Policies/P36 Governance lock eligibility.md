---
type: policy
id: "P36"
group: "Staking"
---
# P36: Governance lock eligibility

[[G6 Governance Stake]] guard. Calls [[P02 Eligibility revalidation]].

## Domain
[[S12 GovernanceLockRequest]]

## Codomain
eligible + adjusted params

## Fires
[[M23 Governance lock]]
