---
type: policy
id: "P15"
group: "Fees"
---
# P15: Campaign fee split

[[G9a Campaign Payout]] / [[G9b Campaign Fee]] / [[G9c Campaign Burn]] three-way split.

## Domain
E6 budget + fee_split config

## Codomain
[[S18 CampaignSettlement]]

## Fires
[[M47 Escrow payout]] + [[M48 Escrow fee route]] + [[M16 Burn Z1U]]
