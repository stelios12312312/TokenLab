---
type: policy
id: "P10"
group: "Settlement"
---
# P10: Settlement eligibility

[[G3 ACR Settlement]] guard. Calls [[P02 Eligibility revalidation]]. Checks AR sufficiency.

## Domain
[[S07 SettlementRequest]]

## Codomain
eligible + max settleable

## Fires
Gates [[M10 Settle ACR]]
