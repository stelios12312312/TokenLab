---
type: policy
id: "P25"
group: "Governance"
---
# P25: Delegation policy

[[G18 Governance Delegation]] / [[G18' Governance Revocation]] rules. No self-delegation, depth cap, cooldown.

## Domain
delegator, delegate, active_votes

## Codomain
delegation valid (bool)

## Fires
[[M26 Delegate governance]] or [[M27 Revoke delegation]]
