---
type: policy
id: "P08"
group: "Scoring"
---
# P08: Loyalty multiplier

Tenure-based earning multiplier. C5: work-proportional, not stake-proportional.

## Domain
registration_epoch, activity_streak

## Codomain
multiplier value (capped)

## Fires
[[M22 Update loyalty multiplier]]
