---
type: policy
id: "P01"
group: "Eligibility"
---
# P01: Verification policy

[[G1 Verification]] decision. Identity proofs to pass/hold/deny + tier A/B/C.

## Domain
[[S01 ClaimRequest]]

## Codomain
[[S02 VerificationResult]]

## Fires
[[M04 Set claim status]]
