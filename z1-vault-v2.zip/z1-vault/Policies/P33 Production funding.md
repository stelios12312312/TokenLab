---
type: policy
id: "P33"
group: "Escrow"
---
# P33: Production funding

Greenlight approved. Escrow creation.

## Domain
greenlight approval

## Codomain
[[S19 ProductionFunding]]

## Fires
[[M46 Create escrow]]
