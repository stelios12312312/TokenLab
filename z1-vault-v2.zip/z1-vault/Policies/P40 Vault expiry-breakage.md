---
type: policy
id: "P40"
group: "System"
---
# P40: Vault expiry-breakage

Vesting window closes with remaining > 0. Burn (default) or AR reflow (governance approved).

## Domain
E5 vault.remaining

## Codomain
burn or reflow

## Fires
[[M45 Vault expiry]]
