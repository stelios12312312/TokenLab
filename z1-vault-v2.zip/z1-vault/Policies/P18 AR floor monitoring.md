---
type: policy
id: "P18"
group: "Scheduling"
---
# P18: AR floor monitoring

Continuous check: AR(t) < alpha_floor * Z1U_Circulating(t)? Critical monetary policy automation.

## Domain
AR balance, circulating supply, alpha_floor (>=0.25)

## Codomain
top_up_needed + amount

## Fires
[[M42 AR floor top-up]]
