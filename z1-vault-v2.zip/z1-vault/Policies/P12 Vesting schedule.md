---
type: policy
id: "P12"
group: "Settlement"
---
# P12: Vesting schedule

[[G14 Vesting Progression]] logic. Per-user: cliff + linear + hash-based stagger offset.

## Domain
E2 vesting state + params

## Codomain
vested_amount this epoch

## Fires
[[M06 Vest ACR]]. Guard: claim_status = pass.
