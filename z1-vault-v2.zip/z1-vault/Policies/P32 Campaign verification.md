---
type: policy
id: "P32"
group: "Escrow"
---
# P32: Campaign verification

[[G9a Campaign Payout]]. Did campaign hit verified attention target?

## Domain
E6 attention data

## Codomain
settlement_eligible

## Fires
[[M47 Escrow payout]] or [[M49 Cancel escrow]]
