---
type: policy
id: "P03"
group: "Eligibility"
---
# P03: Tier assignment

Determines verification tier from proof type. Called within P01. OTT direct=A, Statistical=B, Community=C.

## Domain
identity_proofs

## Codomain
tier (A/B/C)

## Fires
Embedded in [[P01 Verification policy]]
