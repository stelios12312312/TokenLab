---
type: policy
id: "P02"
group: "Eligibility"
---
# P02: Eligibility revalidation

Called at every benefit gate (G3,G4,G6,G9,G10). Re-checks claim_status. C5 compliance enforcement surface.

## Domain
agent_id + gate_id

## Codomain
[[S03 EligibilityCheck]]

## Fires
Sub-policy (guard). Does not fire mechanism directly.
