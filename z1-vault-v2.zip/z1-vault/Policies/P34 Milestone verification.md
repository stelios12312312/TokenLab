---
type: policy
id: "P34"
group: "Escrow"
---
# P34: Milestone verification

Milestone delivered. Should tranche release? A7 validator attests.

## Domain
Evidence, validator attestation

## Codomain
[[S20 MilestoneVerification]]

## Fires
[[M47 Escrow payout]] or [[M51 Slash production escrow]]
