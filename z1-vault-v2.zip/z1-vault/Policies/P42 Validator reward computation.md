---
type: policy
id: "P42"
group: "System"
---
# P42: Validator reward computation

[[G15a Validator Rewards]] stipend. C5: work-proportional (uptime * accuracy), not bond-proportional.

## Domain
uptime, accuracy, bonded

## Codomain
stipend_amount

## Fires
[[M35 Pay validator stipend]]
