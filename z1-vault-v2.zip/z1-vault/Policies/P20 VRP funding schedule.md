---
type: policy
id: "P20"
group: "Scheduling"
---
# P20: VRP funding schedule

[[G15_fund VRP Funding]]. Treasury to Validator Reward Pool. Epoch-based or governance-approved.

## Domain
VRP balance, validator count, Treasury budget

## Codomain
fund amount

## Fires
[[M44 VRP funding]]
