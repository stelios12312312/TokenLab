---
type: policy
id: "P26"
group: "Integrity"
---
# P26: Hold decision

When to freeze agent ACR. Triggered by anomaly detection or external report.

## Domain
anomaly_score, external_report, history

## Codomain
hold (bool) + reason + scope

## Fires
[[M07 Hold ACR]]
