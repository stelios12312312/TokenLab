---
type: policy
id: "P31"
group: "Escrow"
---
# P31: Campaign creation

[[G8 Campaign Deposit]]. Validate campaign terms before creating escrow.

## Domain
[[S17 CampaignDeposit]]

## Codomain
approved + config

## Fires
[[M46 Create escrow]]
