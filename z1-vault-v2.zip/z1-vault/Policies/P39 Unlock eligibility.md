---
type: policy
id: "P39"
group: "Staking"
---
# P39: Unlock eligibility

Any lock type. Can funds return to balance? Checks expiry, active votes, production status.

## Domain
agent_id, lock_type

## Codomain
eligible + unlockable

## Fires
[[M24 Governance unlock]] / [[M31 Producer stake unlock]] / [[M29 Vote escrow release]]
