---
type: policy
id: "P23"
group: "Governance"
---
# P23: Vote tallying

Determine if proposal passed/rejected/expired. Constitutional: 90% + Trustee (A9) concurrence.

## Domain
E7 vote tallies + thresholds

## Codomain
[[S16 ProposalResolution]]

## Fires
[[M54 Resolve proposal]]
