---
type: policy
id: "P11"
group: "Settlement"
---
# P11: Settlement ratio

ACR to Z1U conversion rate. TBD: fixed / dynamic / governed. Highest uncertainty parameter.

## Domain
acr_amount, params

## Codomain
z1u_amount

## Fires
Feeds [[S08 SettlementExecution]]
