---
type: policy
id: "P28"
group: "Integrity"
---
# P28: Slash amount

[[G13a Z1U Slashing]] penalty computation. -200% for ACR fraud. Escalating for repeat offenders.

## Domain
slash_type, history, locked_amount

## Codomain
slash_amount + destination (always treasury)

## Fires
[[M33 Slash agent]]
