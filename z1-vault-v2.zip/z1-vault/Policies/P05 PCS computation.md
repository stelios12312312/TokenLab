---
type: policy
id: "P05"
group: "Scoring"
---
# P05: PCS computation

Core scoring engine per Yellow Paper. 4-signal normalization + weighting + bounding + anomaly discount.

## Domain
[[S04 ContributionSignals]]

## Codomain
[[S05 PCSOutput]]

## Fires
[[M05 Issue ACR]] or [[M07 Hold ACR]]
