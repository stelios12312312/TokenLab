---
type: policy
id: "P30"
group: "Integrity"
---
# P30: Succession eligibility

G17 succession variant. Can dormant ACR transfer to successor?

## Domain
dormant_agent, successor

## Codomain
eligible (bool)

## Fires
[[M13 ACR succession transfer]]. One-time, irreversible.
