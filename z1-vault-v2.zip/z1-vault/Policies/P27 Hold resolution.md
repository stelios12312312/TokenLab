---
type: policy
id: "P27"
group: "Integrity"
---
# P27: Hold resolution

How/when holds resolve. IR (A8) scenario switch controls outcome.

## Domain
hold_reason, investigation, elapsed

## Codomain
release / escalate / void

## Fires
[[M08 Release hold]] or [[M09 Void ACR]] + [[M33 Slash agent]]
