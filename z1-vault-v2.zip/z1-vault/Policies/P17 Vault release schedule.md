---
type: policy
id: "P17"
group: "Scheduling"
---
# P17: Vault release schedule

Per-epoch vault unlock computation. Per bucket type: epochal / cliff+linear / governed / milestone.

## Domain
E5 vault state + schedule params

## Codomain
[[S21 VaultRelease]]

## Fires
[[M39 Vault release]]
