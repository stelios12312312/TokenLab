---
type: policy
id: "P07"
group: "Scoring"
---
# P07: Access tier computation

Deterministic tier from z1u_balance vs tier_thresholds.

## Domain
z1u_balance

## Codomain
tier (Bronze/Silver/Gold/Platinum)

## Fires
[[M21 Update access tier]]
