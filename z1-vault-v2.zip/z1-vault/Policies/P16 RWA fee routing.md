---
type: policy
id: "P16"
group: "Fees"
---
# P16: RWA fee routing

[[G10 RWA Fee Route]]. Fee from RWA activity to Treasury only. Never directly to users.

## Domain
RWA transaction data

## Codomain
fee amount + routing

## Fires
[[M15 Transfer Z1U]] to Treasury via [[M40 Pool inflow]]
