---
type: policy
id: "P38"
group: "Staking"
---
# P38: Verifier bond eligibility

A7 validator wants to bond.

## Domain
agent_id, amount

## Codomain
eligible

## Fires
[[M32 Verifier bond lock]]
