---
type: policy
id: "P44"
group: "System"
---
# P44: Operational outflow

[[G16 Operational Outflow]]. Governance-approved budget envelope. Cannot fund AR-eligible purposes or price support.

## Domain
budget_id, amount, purpose

## Codomain
approved (bool)

## Fires
[[M41 Pool outflow]] on Treasury
