---
type: policy
id: "P13"
group: "Settlement"
---
# P13: Settlement queue

When AR cannot cover all settlements. FIFO + optional tier priority.

## Domain
Queue of pending S08 + AR balance

## Codomain
ordered execution list

## Fires
Queue drains as AR refills via [[G11 AR Top-up]].
