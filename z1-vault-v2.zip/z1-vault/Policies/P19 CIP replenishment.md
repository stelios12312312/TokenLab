---
type: policy
id: "P19"
group: "Scheduling"
---
# P19: CIP replenishment

Epoch-cadence budget routing Treasury to CIP.

## Domain
CIP balance, programme budgets, Treasury balance

## Codomain
replenish amount

## Fires
[[M43 CIP replenish]]
