---
type: policy
id: "P04"
group: "Eligibility"
---
# P04: Tier upgrade

Agent submits stronger proofs after initial verification. Prospective recalculation.

## Domain
agent_id + new proofs

## Codomain
updated tier + PCS recalc

## Fires
[[M04 Set claim status]]
