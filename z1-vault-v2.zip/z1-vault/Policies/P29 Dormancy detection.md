---
type: policy
id: "P29"
group: "Integrity"
---
# P29: Dormancy detection

[[G17 ACR Expiry - Breakage]]. 24-month dormancy threshold. Staged: warn then suspend then void then succession.

## Domain
dormancy_counter, thresholds

## Codomain
[[S24 DormancyEvent]]

## Fires
[[M11 Increment dormancy]] then [[M12 Execute dormancy action]]
