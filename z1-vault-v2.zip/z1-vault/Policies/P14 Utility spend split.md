---
type: policy
id: "P14"
group: "Fees"
---
# P14: Utility spend split

[[G5a Utility Spend]] / [[G5b Protocol Fee]] / [[G5c Sink-Burn]] three-way split.

## Domain
gross_amount + SKU

## Codomain
[[S10 UtilitySpendReceipt]]

## Fires
[[M15 Transfer Z1U]] + [[M40 Pool inflow]] + [[M16 Burn Z1U]]
