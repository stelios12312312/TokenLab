---
type: policy
id: "P22"
group: "Governance"
---
# P22: Proposal eligibility

Can this agent submit a proposal? Silver tier minimum (DOC-019).

## Domain
gov_weight, proposal_type, tier

## Codomain
eligible (bool)

## Fires
[[M52 Create proposal]]
