---
type: policy
id: "P24"
group: "Governance"
---
# P24: Parameter bounds

Validates proposed values within bounded ranges. Hard constraint, not vote-overridable.

## Domain
target_param + proposed_value

## Codomain
valid (bool)

## Fires
Enforced at submission time
