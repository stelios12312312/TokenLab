---
type: policy
id: "P43"
group: "System"
---
# P43: Treasury health throttle

[[SYS_throttle Treasury Health Feedback]]. Fires when T(t) / total outflow demand < theta_min.

## Domain
treasury_health metric

## Codomain
throttle actions

## Fires
[[M57 Execute throttle]]. Reduces PCS weights, extends vesting, lowers issuance.
