---
type: policy
id: "P21"
group: "Governance"
---
# P21: Governance weight computation

Calculate voting power. Anti-capture: weight=0 if claim_status != pass. Concentration cap enforced.

## Domain
z1u_staked, time, ACR status

## Codomain
gov_weight

## Fires
[[M25 Update governance weight]]
