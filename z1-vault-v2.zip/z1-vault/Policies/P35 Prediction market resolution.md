---
type: policy
id: "P35"
group: "Escrow"
---
# P35: Prediction market resolution

Outcome determined. Redistribute stakes to winners.

## Domain
E6 prediction + resolved outcome

## Codomain
payout per winner

## Fires
[[M47 Escrow payout]] + [[M48 Escrow fee route]] + [[M50 Close escrow]]
