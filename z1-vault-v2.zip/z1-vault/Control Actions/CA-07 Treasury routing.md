---
type: control_action
id: "CA-07"
---
# CA-07: Treasury routing

Sequential: AR first ([[G11 AR Top-up]]), then CIP ([[G12 CIP Replenish]]), then VRP ([[G15_fund VRP Funding]]). AR has priority.

## Pipeline
[[P18 AR floor monitoring]] then [[M42 AR floor top-up]] then [[P19 CIP replenishment]] then [[M43 CIP replenish]] then [[P20 VRP funding schedule]] then [[M44 VRP funding]]
