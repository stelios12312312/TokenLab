---
type: control_action
id: "CA-01"
---
# CA-01: Epoch tick

Every epoch. Advances clock, resets accumulators.

## Pipeline
[[M01 Increment epoch]]
