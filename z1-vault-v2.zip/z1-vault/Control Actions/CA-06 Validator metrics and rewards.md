---
type: control_action
id: "CA-06"
---
# CA-06: Validator metrics and rewards

All A7. Recalculate performance. Accrue stipends from VRP.

## Pipeline
[[M34 Update validator metrics]] then [[P42 Validator reward computation]] then [[M35 Pay validator stipend]]
