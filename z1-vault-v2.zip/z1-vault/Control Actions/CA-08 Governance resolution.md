---
type: control_action
id: "CA-08"
---
# CA-08: Governance resolution

All active proposals checked. Resolve expired voting periods.

## Pipeline
[[P23 Vote tallying]] then [[M54 Resolve proposal]] then [[M55 Execute proposal]] or [[M56 Expire proposal]]
