---
type: control_action
id: "CA-09"
---
# CA-09: Treasury health check

[[SYS_throttle Treasury Health Feedback]]. Automated sustainability brake.

## Pipeline
[[P43 Treasury health throttle]] then [[M57 Execute throttle]] if treasury_health < theta_min
