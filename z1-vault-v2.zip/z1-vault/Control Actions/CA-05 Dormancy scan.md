---
type: control_action
id: "CA-05"
---
# CA-05: Dormancy scan

All agents checked. Increment counter if no contribution.

## Pipeline
[[M11 Increment dormancy]] then [[P29 Dormancy detection]] then [[M12 Execute dormancy action]]
