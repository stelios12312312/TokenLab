---
type: control_action
id: "CA-02"
---
# CA-02: Market state injection

Inject exogenous price/volume from boundary condition.

## Pipeline
[[M02 Update market exogenous]]
