---
type: control_action
id: "CA-04"
---
# CA-04: ACR vesting transition

[[G14 Vesting Progression]]. All A_ACR agents with acr_vesting > 0.

## Pipeline
[[P12 Vesting schedule]] then [[M06 Vest ACR]]
