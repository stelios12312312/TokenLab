---
type: control_action
id: "CA-03"
---
# CA-03: Vault release

All 7 vaults evaluated. Scheduled tokens released to destination pools.

## Pipeline
[[P17 Vault release schedule]] then [[M39 Vault release]] then [[M40 Pool inflow]]
