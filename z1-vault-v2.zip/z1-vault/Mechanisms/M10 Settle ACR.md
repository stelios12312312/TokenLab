---
type: mechanism
id: "M10"
target_entity: "E2"
---
# M10: Settle ACR

**Target entity:** [[E2]]

[[G3 ACR Settlement]]. The ACR to Z1U bridge.

## State writes
E2[agent].acr_available -= X. acr_settled += X. Cross-entity: triggers pool outflow on AR + Z1U credit to agent. Input: [[S08 SettlementExecution]].
