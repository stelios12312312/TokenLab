---
type: mechanism
id: "M05"
target_entity: "E2"
---
# M05: Issue ACR

**Target entity:** [[E2]]

[[G2 Contribution to ACR]] scoring. Posts new recognition credits to A_ACR agents.

## State writes
E2[agent].acr_issued += amount. acr_vesting += amount. pcs_score updated. dormancy_counter reset. Input: [[S06 ACRIssuanceEvent]].
