---
type: mechanism
id: "M21"
target_entity: "E4"
---
# M21: Update access tier

**Target entity:** [[E4]]

Recalculate from z1u_balance vs tier_thresholds. Fires after any balance change.

## State writes
E4[agent].tier <- f(z1u_balance). Deterministic.
