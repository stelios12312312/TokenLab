---
type: mechanism
id: "M18"
target_entity: "E3"
---
# M18: Toggle pause

**Target entity:** [[E3]]

Emergency circuit breaker. Halts all transfers, mints, burns.

## State writes
E3.pause_state <- paused/active. While paused: M15, M16, M17 all reject. Time-limited.
