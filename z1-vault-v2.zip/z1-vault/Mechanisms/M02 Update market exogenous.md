---
type: mechanism
id: "M02"
target_entity: "E1"
---
# M02: Update market exogenous

**Target entity:** [[E1]]

Control action (external feed). Injects [[EXO-06 External Z1U price]] and volume.

## State writes
E1.market_price, E1.market_volume <- boundary condition input.
