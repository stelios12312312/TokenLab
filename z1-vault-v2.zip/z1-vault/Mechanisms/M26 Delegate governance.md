---
type: mechanism
id: "M26"
target_entity: "E4"
---
# M26: Delegate governance

**Target entity:** [[E4]]

[[G18 Governance Delegation]]. Transfer voting power to delegate.

## State writes
E4[delegator].gov_weight decreases. E4[delegate].delegated_weight increases. Guard: both claim_status = pass, no self-delegation, depth cap.
