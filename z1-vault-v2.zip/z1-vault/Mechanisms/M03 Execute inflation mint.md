---
type: mechanism
id: "M03"
target_entity: "E1"
---
# M03: Execute inflation mint

**Target entity:** [[E1]]

Fires only after [[Governance Proposal]] passes 90% + 60d cooling. Extremely rare.

## State writes
E1.Z1U_Minted += amount. E3.total_supply += amount. E3.total_cap updated. inflation_status <- executed.
