---
type: mechanism
id: "M38"
target_entity: "E4"
---
# M38: Update curation-scout metrics

**Target entity:** [[E4]]

Per-epoch A2/A3 updates.

## State writes
curation_accuracy, curation_streak, referral_count, scout_reputation updated.
