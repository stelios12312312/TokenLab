---
type: mechanism
id: "M08"
target_entity: "E2"
---
# M08: Release hold

**Target entity:** [[E2]]

Investigation clears user. Unfreezes ACR.

## State writes
E2[agent].acr_held -= amount. acr_vesting or acr_available += amount. claim_status <- pass.
