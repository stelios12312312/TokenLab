---
type: mechanism
id: "M36"
target_entity: "E4"
---
# M36: Return verifier bond

**Target entity:** [[E4]]

[[G15b Verifier Bond Return]]. Bond back + small reward from VRP.

## State writes
verifier_bond_locked -= bond. z1u_balance += bond + reward. Guard: attestation not flagged, bond period expired.
