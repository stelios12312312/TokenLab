---
type: mechanism
id: "M31"
target_entity: "E4"
---
# M31: Producer stake unlock

**Target entity:** [[E4]]

Lock expired or production delivered.

## State writes
producer_stake_locked -= X. z1u_balance += X.
