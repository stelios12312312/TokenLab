---
type: mechanism
id: "M11"
target_entity: "E2"
---
# M11: Increment dormancy

**Target entity:** [[E2]]

Control action (epoch tick). Counts inactive epochs for [[G17 ACR Expiry - Breakage]].

## State writes
E2[agent].dormancy_counter += 1. Only if last_contribution_epoch < current - 1.
