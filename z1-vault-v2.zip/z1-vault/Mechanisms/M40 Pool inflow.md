---
type: mechanism
id: "M40"
target_entity: "E5"
---
# M40: Pool inflow

**Target entity:** [[E5]]

Generic receive. Bookkeeping for any Z1U entering a pool.

## State writes
E5[pool].balance += X. cumulative_inflow += X.
