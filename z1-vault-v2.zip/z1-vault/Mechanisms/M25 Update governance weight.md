---
type: mechanism
id: "M25"
target_entity: "E4"
---
# M25: Update governance weight

**Target entity:** [[E4]]

Recalculate voting power from lock state + time + ACR status.

## State writes
gov_weight <- f(z1u_staked * time_factor * acr_verified). Zero if claim_status != pass. Concentration cap enforced.
