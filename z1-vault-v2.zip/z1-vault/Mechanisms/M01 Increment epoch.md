---
type: mechanism
id: "M01"
target_entity: "E1"
---
# M01: Increment epoch

**Target entity:** [[E1]]

Control action (time). Advances epoch, resets per-epoch accumulators.

## State writes
E1.epoch <- epoch + 1. Reset transfer_volume, inflow/outflow_this_epoch on all pools.
