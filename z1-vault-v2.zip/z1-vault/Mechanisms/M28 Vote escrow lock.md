---
type: mechanism
id: "M28"
target_entity: "E4"
---
# M28: Vote escrow lock

**Target entity:** [[E4]]

Lock Z1U during active greenlight vote. Temporary.

## State writes
z1u_balance -= X. vote_escrow_amount += X.
