---
type: mechanism
id: "M45"
target_entity: "E5"
---
# M45: Vault expiry

**Target entity:** [[E5]]

Vesting window closes with remaining > 0. Cleanup.

## State writes
E5[vault].expired += remaining. remaining <- 0. Routes to burn (default) or AR reflow (governance).
