---
type: mechanism
id: "M37"
target_entity: "E4"
---
# M37: Update creator milestone

**Target entity:** [[E4]]

A4 milestone progression. Verified delivery triggers CIP payout.

## State writes
milestone_status <- verified. CIP_entitlement -= tranche. Input: [[S20 MilestoneVerification]].
