---
type: mechanism
id: "M42"
target_entity: "E5"
---
# M42: AR floor top-up

**Target entity:** [[E5]]

[[G11 AR Top-up]]. Treasury to AR when floor breached.

## State writes
Outflow on Treasury + inflow on AR. Bounded by topup_cap. Input: [[S22 TreasuryRouting]].
