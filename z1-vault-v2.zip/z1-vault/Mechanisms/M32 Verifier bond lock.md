---
type: mechanism
id: "M32"
target_entity: "E4"
---
# M32: Verifier bond lock

**Target entity:** [[E4]]

A7 validator bonds Z1U as integrity collateral. Slashable via [[G13a Z1U Slashing]].

## State writes
z1u_balance -= X. verifier_bond_locked += X.
