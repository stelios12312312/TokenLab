---
type: mechanism
id: "M53"
target_entity: "E7"
---
# M53: Record vote

**Target entity:** [[E7]]

Agent casts vote on active proposal.

## State writes
vote_tally_for or against += weight. voter_list appended. Input: [[S15 VoteCast]].
