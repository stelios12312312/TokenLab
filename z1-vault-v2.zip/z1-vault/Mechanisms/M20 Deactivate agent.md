---
type: mechanism
id: "M20"
target_entity: "E4"
---
# M20: Deactivate agent

**Target entity:** [[E4]]

Ban, voluntary exit, or terminal dormancy.

## State writes
E4[agent].is_active <- false. All locks eventually released/slashed.
