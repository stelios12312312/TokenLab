---
type: mechanism
id: "M54"
target_entity: "E7"
---
# M54: Resolve proposal

**Target entity:** [[E7]]

Voting period ended. Tally counted, quorum checked.

## State writes
status <- passed/rejected/expired. If constitutional: cooling_period_end set. Release vote escrows.
