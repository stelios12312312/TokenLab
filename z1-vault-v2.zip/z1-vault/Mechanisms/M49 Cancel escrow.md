---
type: mechanism
id: "M49"
target_entity: "E6"
---
# M49: Cancel escrow

**Target entity:** [[E6]]

Refund remaining minus cancellation fee.

## State writes
status <- cancelled. Remaining refunded to creator. Fee to Treasury.
