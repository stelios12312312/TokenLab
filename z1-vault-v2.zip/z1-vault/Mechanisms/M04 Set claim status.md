---
type: mechanism
id: "M04"
target_entity: "E2"
---
# M04: Set claim status

**Target entity:** [[E2]]

[[G1 Verification]] result + revalidation at benefit gates.

## State writes
E2[agent].claim_status <- pending/pass/hold/deny. verification_tier <- A/B/C. Input: [[S02 VerificationResult]].
