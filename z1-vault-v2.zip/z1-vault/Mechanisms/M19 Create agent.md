---
type: mechanism
id: "M19"
target_entity: "E4"
---
# M19: Create agent

**Target entity:** [[E4]]

[[G0 Opt-in]]. Instantiates new agent with initial state.

## State writes
New E4 instance. Balance=0, all locks=0, is_active=true.
