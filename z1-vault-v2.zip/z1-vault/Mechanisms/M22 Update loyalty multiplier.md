---
type: mechanism
id: "M22"
target_entity: "E4"
---
# M22: Update loyalty multiplier

**Target entity:** [[E4]]

Tenure-based. Per epoch for A1-A5.

## State writes
E4[agent].loyalty_multiplier <- f(tenure, activity_streak). Capped. C5: work-proportional.
