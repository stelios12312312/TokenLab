---
type: mechanism
id: "M14"
target_entity: "E2"
---
# M14: Update PCS model version

**Target entity:** [[E2]]

Tracks which scoring model produced a given PCS score. Auditability.

## State writes
E2[agent].pcs_model_version <- current_model. Fires alongside [[M05 Issue ACR]].
