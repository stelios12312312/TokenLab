---
type: mechanism
id: "M44"
target_entity: "E5"
---
# M44: VRP funding

**Target entity:** [[E5]]

[[G15_fund VRP Funding]]. Treasury to Validator Reward Pool.

## State writes
Outflow on Treasury + inflow on VRP. Epoch-based or governance-approved. Input: [[S22 TreasuryRouting]].
