---
type: mechanism
id: "M07"
target_entity: "E2"
---
# M07: Hold ACR

**Target entity:** [[E2]]

Integrity/compliance flag. Freezes ACR and blocks benefit gates.

## State writes
E2[agent].acr_held += amount. acr_vesting or acr_available -= same. claim_status <- hold.
