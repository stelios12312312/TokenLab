---
type: mechanism
id: "M52"
target_entity: "E7"
---
# M52: Create proposal

**Target entity:** [[E7]]

Agent submits new governance proposal. Silver tier minimum (DOC-019).

## State writes
New E7 instance. Input: [[S14 ProposalSubmission]]. Guard: min gov_weight, proposer tier >= Silver.
