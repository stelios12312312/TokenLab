---
type: mechanism
id: "M46"
target_entity: "E6"
---
# M46: Create escrow

**Target entity:** [[E6]]

New instance. Debits funding source. Campaign via [[G8 Campaign Deposit]], production via greenlight.

## State writes
New E6. budget_total, budget_remaining = total, status = active.
