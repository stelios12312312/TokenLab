---
type: mechanism
id: "M27"
target_entity: "E4"
---
# M27: Revoke delegation

**Target entity:** [[E4]]

[[G18' Governance Revocation]]. Recall delegated voting power.

## State writes
Delegated weight returns to delegator. Cooldown enforced if delegate has active votes.
