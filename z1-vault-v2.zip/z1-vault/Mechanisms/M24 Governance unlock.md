---
type: mechanism
id: "M24"
target_entity: "E4"
---
# M24: Governance unlock

**Target entity:** [[E4]]

[[G6' Governance Unlock]]. Lock expired. Return to balance.

## State writes
z1u_staked -= X. z1u_balance += X. gov_weight zeroed. Guard: epoch >= start + duration, no active votes. Early exit penalty to Treasury if permitted.
