---
type: mechanism
id: "M41"
target_entity: "E5"
---
# M41: Pool outflow

**Target entity:** [[E5]]

Generic distribute. Guard: mandate check, amount <= balance.

## State writes
E5[pool].balance -= X. cumulative_outflow += X.
