---
type: mechanism
id: "M43"
target_entity: "E5"
---
# M43: CIP replenish

**Target entity:** [[E5]]

[[G12 CIP Replenish]]. Epoch-cadence Treasury to CIP.

## State writes
Outflow on Treasury + inflow on CIP. Input: [[S22 TreasuryRouting]].
