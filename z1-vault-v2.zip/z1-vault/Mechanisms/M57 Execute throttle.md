---
type: mechanism
id: "M57"
target_entity: "E1"
---
# M57: Execute throttle

**Target entity:** [[E1]]

[[SYS_throttle Treasury Health Feedback]]. Automated sustainability brake.

## State writes
Reduce PCS weights, extend vesting duration, lower issuance rate when treasury_health < theta_min.
