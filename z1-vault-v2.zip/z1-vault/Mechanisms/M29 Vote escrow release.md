---
type: mechanism
id: "M29"
target_entity: "E4"
---
# M29: Vote escrow release

**Target entity:** [[E4]]

Vote resolved. Return escrowed Z1U.

## State writes
vote_escrow_amount -= X. z1u_balance += X.
