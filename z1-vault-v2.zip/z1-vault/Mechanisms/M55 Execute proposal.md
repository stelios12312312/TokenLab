---
type: mechanism
id: "M55"
target_entity: "E7"
---
# M55: Execute proposal

**Target entity:** [[E7]]

Cooling complete (if applicable). Apply parameter change.

## State writes
Target parameter updated to proposed_value. status <- executed.
