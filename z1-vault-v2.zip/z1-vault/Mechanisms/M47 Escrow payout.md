---
type: mechanism
id: "M47"
target_entity: "E6"
---
# M47: Escrow payout

**Target entity:** [[E6]]

[[G9a Campaign Payout]] or milestone tranche. Release Z1U to recipients.

## State writes
budget_remaining -= payout. Z1U transfer to recipients.
