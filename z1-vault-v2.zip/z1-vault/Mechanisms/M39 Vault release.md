---
type: mechanism
id: "M39"
target_entity: "E5"
---
# M39: Vault release

**Target entity:** [[E5]]

Control action. Scheduled unlock per vault schedule.

## State writes
E5[vault].released += X. remaining -= X. Destination pool receives. Input: [[S21 VaultRelease]].
