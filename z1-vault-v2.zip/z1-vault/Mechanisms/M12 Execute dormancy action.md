---
type: mechanism
id: "M12"
target_entity: "E2"
---
# M12: Execute dormancy action

**Target entity:** [[E2]]

[[G17 ACR Expiry - Breakage]]. 24-month dormancy threshold breached.

## State writes
Warn / suspend (hold) / void / succession. Input: [[S24 DormancyEvent]].
