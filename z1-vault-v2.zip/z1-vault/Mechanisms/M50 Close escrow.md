---
type: mechanism
id: "M50"
target_entity: "E6"
---
# M50: Close escrow

**Target entity:** [[E6]]

Terminal. All funds distributed or refunded.

## State writes
status <- settled or cancelled. budget_remaining must = 0. Instance archived.
