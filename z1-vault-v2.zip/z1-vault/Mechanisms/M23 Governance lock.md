---
type: mechanism
id: "M23"
target_entity: "E4"
---
# M23: Governance lock

**Target entity:** [[E4]]

[[G6 Governance Stake]]. Lock Z1U for governance. Requires ACR verification.

## State writes
z1u_balance -= X. z1u_staked += X. Set lock start + duration. Input: [[S12 GovernanceLockRequest]].
