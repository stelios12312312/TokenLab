---
type: mechanism
id: "M15"
target_entity: "E3"
---
# M15: Transfer Z1U

**Target entity:** [[E3]]

Universal token movement. Most connected mechanism. Every Z1U flow routes through this.

## State writes
E3[from].balance -= X. E3[to].balance += X. transfer_volume_epoch += X. Guard: balance >= amount, pause_state != paused. Input: [[S09 Z1UTransfer]].
