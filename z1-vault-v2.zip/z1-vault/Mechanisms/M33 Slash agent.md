---
type: mechanism
id: "M33"
target_entity: "E4"
---
# M33: Slash agent

**Target entity:** [[E4]]

[[G13a Z1U Slashing]]. -200% penalty. Debits locked funds, routes to Treasury.

## State writes
Debit z1u_staked or verifier_bond. to Treasury via pool inflow. Due process required (evidence, 14-day appeal, independent review). Input: [[S23 SlashEvent]].
