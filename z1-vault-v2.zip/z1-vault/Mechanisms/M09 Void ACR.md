---
type: mechanism
id: "M09"
target_entity: "E2"
---
# M09: Void ACR

**Target entity:** [[E2]]

[[G13b ACR Voiding]]. Terminal. Fraud confirmed. Permanently removes ACR.

## State writes
E2[agent].acr_voided += amount. acr_held -= amount. Monotonic, irreversible. Reduces settlement pressure on AR.
