---
type: mechanism
id: "M34"
target_entity: "E4"
---
# M34: Update validator metrics

**Target entity:** [[E4]]

Per-epoch A7 performance recalculation.

## State writes
uptime, fraud_catch_rate, attestation_accuracy <- rolling average.
