---
type: mechanism
id: "M13"
target_entity: "E2"
---
# M13: ACR succession transfer

**Target entity:** [[E2]]

G17 succession variant. Moves ACR from dormant to verified successor.

## State writes
E2[original].acr to E2[successor].acr_vesting. One-time, irreversible. Guard: successor claim_status = pass.
