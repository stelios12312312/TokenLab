---
type: mechanism
id: "M51"
target_entity: "E6"
---
# M51: Slash production escrow

**Target entity:** [[E6]]

Studio fails delivery. Penalty on escrowed funds.

## State writes
budget_remaining -= slash. Routes to burn or Treasury. May also trigger [[M33 Slash agent]].
