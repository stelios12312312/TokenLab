---
type: mechanism
id: "M17"
target_entity: "E3"
---
# M17: Mint Z1U

**Target entity:** [[E3]]

Inflation-only. Creates new Z1U above genesis cap. Paired with [[M03 Execute inflation mint]].

## State writes
E3.total_supply += amount. Guard: [[Governance Proposal]] passed + cooling complete.
