---
type: mechanism
id: "M48"
target_entity: "E6"
---
# M48: Escrow fee route

**Target entity:** [[E6]]

[[G9b Campaign Fee]]. Fee slice to Treasury + optional [[G9c Campaign Burn]].

## State writes
budget_remaining -= fee. Treasury inflow + optional burn.
