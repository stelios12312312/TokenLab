---
type: mechanism
id: "M30"
target_entity: "E4"
---
# M30: Producer stake lock

**Target entity:** [[E4]]

A5 studio locks Z1U for greenlight proposal. 120-day returnable.

## State writes
z1u_balance -= X. producer_stake_locked += X. Set expiry.
