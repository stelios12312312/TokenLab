---
type: mechanism
id: "M56"
target_entity: "E7"
---
# M56: Expire proposal

**Target entity:** [[E7]]

No quorum. No action taken.

## State writes
status <- expired. Release vote escrows.
