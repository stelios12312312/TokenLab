---
type: mechanism
id: "M16"
target_entity: "E3"
---
# M16: Burn Z1U

**Target entity:** [[E3]]

Permanent removal. Source-tagged. Used by [[G5c Sink-Burn]], [[G9c Campaign Burn]], [[G13a Z1U Slashing]], A2E, breakage.

## State writes
E3[source].balance -= X. total_supply -= X. E1.Z1U_Burned += X. burn_registry[source_type] += X. Input: [[S11 BurnEvent]].
