---
type: mechanism
id: "M06"
target_entity: "E2"
---
# M06: Vest ACR

**Target entity:** [[E2]]

[[G14 Vesting Progression]]. Control action (epoch tick). Moves matured credits Vesting to Available.

## State writes
E2[agent].acr_vesting -= X. acr_available += X. Cliff + linear schedule. Hash-based stagger. Guard: claim_status = pass.
