---
type: mechanism
id: "M35"
target_entity: "E4"
---
# M35: Pay validator stipend

**Target entity:** [[E4]]

[[G15a Validator Rewards]]. Per-epoch from VRP. C5: work-proportional, not stake-proportional.

## State writes
stipend_accrued += earned. On pay: accrued <- 0, VRP outflow, Z1U transfer to validator.
