---
type: exogenous_variable
id: "EXO-02"
symbol: "c(t)"
---
# EXO-02: User churn rate

**Symbol:** `c(t)`
**Description:** Departing viewers per epoch

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
