---
type: exogenous_variable
id: "EXO-08"
symbol: "fx(t)"
---
# EXO-08: Fiat exchange rates

**Symbol:** `fx(t)`
**Description:** Relevant currency pairs

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
