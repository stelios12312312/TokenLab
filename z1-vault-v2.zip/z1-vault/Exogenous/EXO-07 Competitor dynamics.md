---
type: exogenous_variable
id: "EXO-07"
symbol: "comp(t)"
---
# EXO-07: Competitor dynamics

**Symbol:** `comp(t)`
**Description:** Competing platform actions

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
