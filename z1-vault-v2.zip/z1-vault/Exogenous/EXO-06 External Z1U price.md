---
type: exogenous_variable
id: "EXO-06"
symbol: "P(t)"
---
# EXO-06: External Z1U price

**Symbol:** `P(t)`
**Description:** Market price if externally tradeable

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
