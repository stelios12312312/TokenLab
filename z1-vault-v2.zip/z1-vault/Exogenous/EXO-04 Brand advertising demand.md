---
type: exogenous_variable
id: "EXO-04"
symbol: "d(t)"
---
# EXO-04: Brand advertising demand

**Symbol:** `d(t)`
**Description:** Campaign budget inflow per epoch

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
