---
type: exogenous_variable
id: "EXO-05"
symbol: "m(t)"
---
# EXO-05: Macro sentiment

**Symbol:** `m(t)`
**Description:** General crypto market conditions

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
