---
type: exogenous_variable
id: "EXO-09"
symbol: "gas(t)"
---
# EXO-09: Gas/infrastructure costs

**Symbol:** `gas(t)`
**Description:** On-chain transaction costs

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
