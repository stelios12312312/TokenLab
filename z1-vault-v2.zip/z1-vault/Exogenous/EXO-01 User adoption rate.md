---
type: exogenous_variable
id: "EXO-01"
symbol: "a(t)"
---
# EXO-01: User adoption rate

**Symbol:** `a(t)`
**Description:** New viewers per epoch

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
