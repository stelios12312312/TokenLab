---
type: exogenous_variable
id: "EXO-03"
symbol: "q(t)"
---
# EXO-03: Content production rate

**Symbol:** `q(t)`
**Description:** New content items per epoch

Outside the system boundary. Must be parameterized as scenario inputs for simulation.
