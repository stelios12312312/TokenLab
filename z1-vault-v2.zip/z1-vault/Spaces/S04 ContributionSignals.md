---
type: space
id: "S04"
group: "Scoring"
---
# S04: ContributionSignals

Raw participation data into [[G2 Contribution to ACR]] scoring. Per-user per-epoch.

## Schema
```
agent_id: AgentID, epoch: Epoch, tenure_months: Int, integrity_score: Float, platform_diversity: Set, referral_graph_position: Float, anomaly_score_gamma: Float[0,1], verification_tier: Enum, model_version: String
```
