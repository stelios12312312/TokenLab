---
type: space
id: "S02"
group: "Identity"
---
# S02: VerificationResult

Output of [[G1 Verification]] policy. Sets claim_status and tier.

## Schema
```
agent_id: AgentID, claim_status: Enum(pending/pass/hold/deny), verification_tier: Enum(A/B/C), denial_reason: Optional[String]
```
