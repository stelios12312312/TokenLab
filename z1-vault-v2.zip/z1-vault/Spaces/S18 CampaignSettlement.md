---
type: space
id: "S18"
group: "Escrow"
---
# S18: CampaignSettlement

[[G9a Campaign Payout]] / [[G9b Campaign Fee]] / [[G9c Campaign Burn]] three-way split.

## Schema
```
escrow_id: EscrowID, attention_verified: Float, payout_per_recipient: Map[AgentID,Float], fee_to_treasury: Float, burn_amount: Float
```
