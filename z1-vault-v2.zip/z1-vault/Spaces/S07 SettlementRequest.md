---
type: space
id: "S07"
group: "Settlement"
---
# S07: SettlementRequest

Agent initiates [[G3 ACR Settlement]]. Requests ACR to Z1U conversion.

## Schema
```
agent_id: AgentID, acr_amount_requested: Float, settlement_type: Enum(full/partial)
```
