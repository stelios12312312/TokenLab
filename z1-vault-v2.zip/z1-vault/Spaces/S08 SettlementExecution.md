---
type: space
id: "S08"
group: "Settlement"
---
# S08: SettlementExecution

[[G3 ACR Settlement]] policy output. Instruction to debit ACR, debit AR, credit Z1U.

## Schema
```
agent_id: AgentID, acr_debited: Float, z1u_credited: Float, settlement_ratio: Float, ar_sufficient: Boolean, queued: Boolean
```
