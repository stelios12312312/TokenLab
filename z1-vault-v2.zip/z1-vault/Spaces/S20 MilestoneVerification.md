---
type: space
id: "S20"
group: "Escrow"
---
# S20: MilestoneVerification

Milestone delivered, verified, tranche released.

## Schema
```
escrow_id: EscrowID, milestone_index: Int, verified: Boolean, tranche_released: Float, verifier_agent_id: AgentID
```
