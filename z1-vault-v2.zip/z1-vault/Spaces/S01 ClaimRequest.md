---
type: space
id: "S01"
group: "Identity"
---
# S01: ClaimRequest

Agent submits opt-in + identity proofs. Flows from [[G0 Opt-in]] into [[G1 Verification]].

## Schema
```
agent_id: AgentID, identity_proofs: List[Proof], jurisdiction: String, consent_timestamp: Epoch, claim_channel: Enum(OTT/DTH/mobile/web)
```
