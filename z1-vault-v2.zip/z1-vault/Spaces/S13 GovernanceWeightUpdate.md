---
type: space
id: "S13"
group: "Governance"
---
# S13: GovernanceWeightUpdate

[[G6 Governance Stake]] policy result. Writes new governance weight.

## Schema
```
agent_id: AgentID, new_weight: Float, lock_expiry_epoch: Epoch, delegation_active: Boolean
```
