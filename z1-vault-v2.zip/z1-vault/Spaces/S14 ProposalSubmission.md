---
type: space
id: "S14"
group: "Governance"
---
# S14: ProposalSubmission

Agent creates [[Governance Proposal]].

## Schema
```
proposer_id: AgentID, proposal_type: Enum, target_param: String, proposed_value: Any
```
