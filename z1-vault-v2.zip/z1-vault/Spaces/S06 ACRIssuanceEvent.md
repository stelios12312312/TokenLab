---
type: space
id: "S06"
group: "Scoring"
---
# S06: ACRIssuanceEvent

[[G2 Contribution to ACR]] policy output to ACR Ledger. The actual write instruction.

## Schema
```
agent_id: AgentID, epoch: Epoch, amount: Float, vesting_schedule: VestingConfig, integrity_flag: Optional[HoldTrigger]
```
