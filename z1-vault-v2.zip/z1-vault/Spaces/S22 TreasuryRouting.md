---
type: space
id: "S22"
group: "System Ops"
---
# S22: TreasuryRouting

[[G11 AR Top-up]], [[G12 CIP Replenish]], [[G15_fund VRP Funding]], [[G16 Operational Outflow]].

## Schema
```
routing_type: Enum(G11/G12/G15_fund/G16), amount: Float, source: PoolID(Treasury), destination: PoolID, trigger: Enum
```
