---
type: space
id: "S23"
group: "System Ops"
---
# S23: SlashEvent

[[G13a Z1U Slashing]] and [[G13b ACR Voiding]] fraud/non-delivery penalty.

## Schema
```
agent_id: AgentID, slash_type: Enum(validator_bond/producer_stake/acr_fraud), z1u_amount: Float, acr_amount: Float, destination: Enum(treasury), evidence_hash: Hash
```
