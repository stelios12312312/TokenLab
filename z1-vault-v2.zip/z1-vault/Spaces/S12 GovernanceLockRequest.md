---
type: space
id: "S12"
group: "Governance"
---
# S12: GovernanceLockRequest

Agent activates [[G6 Governance Stake]]. Locks Z1U for governance power.

## Schema
```
agent_id: AgentID, lock_amount: Float, lock_duration: Epochs, delegate_to: Optional[AgentID]
```
