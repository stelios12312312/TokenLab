---
type: space
id: "S03"
group: "Identity"
---
# S03: EligibilityCheck

Reused at every benefit gate (G3, G4, G6, G9, G10). Revalidates claim_status. C5 compliance enforcement surface. Most reused space.

## Schema
```
agent_id: AgentID, gate_id: GateID, current_claim_status: Enum, is_eligible: Boolean, block_reason: Optional[String]
```
