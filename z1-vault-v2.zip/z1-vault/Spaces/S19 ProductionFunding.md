---
type: space
id: "S19"
group: "Escrow"
---
# S19: ProductionFunding

Greenlight approved. Creates production escrow.

## Schema
```
studio_id: AgentID, budget: Float, milestone_count: Int, source_pool: PoolID, delivery_deadline: Epoch
```
