---
type: space
id: "S16"
group: "Governance"
---
# S16: ProposalResolution

Outcome after voting closes.

## Schema
```
proposal_id: ProposalID, outcome: Enum(passed/rejected/expired), quorum_met: Boolean, execution_epoch: Optional[Epoch]
```
