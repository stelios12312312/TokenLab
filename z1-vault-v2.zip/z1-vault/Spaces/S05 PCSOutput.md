---
type: space
id: "S05"
group: "Scoring"
---
# S05: PCSOutput

Result of PCS computation. Determines ACR credit amount this epoch.

## Schema
```
agent_id: AgentID, epoch: Epoch, raw_score: Float, bounded_score: Float[alpha,beta], anomaly_adjusted: Float, acr_credit_amount: Float, model_version: String, input_receipt_hash: Hash
```
