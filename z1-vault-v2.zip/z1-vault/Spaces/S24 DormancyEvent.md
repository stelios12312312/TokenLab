---
type: space
id: "S24"
group: "System Ops"
---
# S24: DormancyEvent

[[G17 ACR Expiry - Breakage]] trigger. Agent inactive past 24 months.

## Schema
```
agent_id: AgentID, inactive_epochs: Int, action: Enum(warn/suspend/void/succession), acr_affected: Float
```
