---
type: space
id: "S15"
group: "Governance"
---
# S15: VoteCast

Agent votes on active proposal.

## Schema
```
voter_id: AgentID, proposal_id: ProposalID, direction: Enum(for/against), weight_applied: Float
```
