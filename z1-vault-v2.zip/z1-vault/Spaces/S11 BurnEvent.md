---
type: space
id: "S11"
group: "Settlement"
---
# S11: BurnEvent

Terminal flow. Z1U permanently removed. Source-tagged for audit.

## Schema
```
source: Enum(utility_fee/campaign_fee/slash/a2e_api/breakage), amount: Float, epoch: Epoch
```
