---
type: space
id: "S21"
group: "System Ops"
---
# S21: VaultRelease

Per-epoch vault unlock. Control action (no agent triggers it, time does).

## Schema
```
vault_id: PoolID, epoch: Epoch, release_amount: Float, destination_pool: PoolID, schedule_complete: Boolean
```
