---
type: space
id: "S17"
group: "Escrow"
---
# S17: CampaignDeposit

Brand funds A2E campaign via [[G8 Campaign Deposit]].

## Schema
```
brand_id: AgentID, budget: Float, attention_target: Float, fee_split: {recipient_pct, treasury_pct, burn_pct}
```
