---
type: space
id: "S10"
group: "Settlement"
---
# S10: UtilitySpendReceipt

[[G5a Utility Spend]] / [[G5b Protocol Fee]] / [[G5c Sink-Burn]] three-way split from single spend event.

## Schema
```
agent_id: AgentID, sku_id: String, gross_amount: Float, net_to_destination: Float(G5a), fee_to_treasury: Float(G5b), burn_amount: Float(G5c)
```
