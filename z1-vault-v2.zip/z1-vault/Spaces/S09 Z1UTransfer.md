---
type: space
id: "S09"
group: "Settlement"
---
# S09: Z1UTransfer

Any Z1U movement between addresses. Universal transfer space. Used by G3, G4, G5a, G7, G9a, G10, G15a, G15b.

## Schema
```
from_address: Address, to_address: Address, amount: Float, transfer_type: Enum, epoch: Epoch
```
