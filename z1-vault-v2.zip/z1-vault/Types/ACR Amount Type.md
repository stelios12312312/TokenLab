---
type: type
base: "Float"
---
# ACR Amount Type
**Base:** `Float`

Non-negative ACR recognition credits. Soulbound
