---
type: type
base: "Dict{recipient, treasury, burn}"
---
# Fee Split Type
**Base:** `Dict{recipient, treasury, burn}`

Three-way fee config. Sum = 1.0
