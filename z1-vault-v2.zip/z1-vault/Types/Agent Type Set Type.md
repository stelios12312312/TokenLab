---
type: type
base: "Set[A1..A14]"
---
# Agent Type Set Type
**Base:** `Set[A1..A14]`

Multi-membership agent type flags
