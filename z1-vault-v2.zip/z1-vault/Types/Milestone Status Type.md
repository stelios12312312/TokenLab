---
type: type
base: "Enum[pending, delivered, verified, slashed]"
---
# Milestone Status Type
**Base:** `Enum[pending, delivered, verified, slashed]`

Creator milestone status
