---
type: type
base: "Enum[vault, operational]"
---
# Pool Type Type
**Base:** `Enum[vault, operational]`

Genesis vault vs operational pool
