---
type: type
base: "String"
---
# Escrow ID Type
**Base:** `String`

Unique escrow instance identifier
