---
type: type
base: "Dict{utility, campaign, slash, a2e, breakage}"
---
# Burn Registry Type
**Base:** `Dict{utility, campaign, slash, a2e, breakage}`

Per-source burn accounting
