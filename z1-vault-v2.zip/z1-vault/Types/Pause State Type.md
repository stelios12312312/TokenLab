---
type: type
base: "Enum[active, paused]"
---
# Pause State Type
**Base:** `Enum[active, paused]`

Emergency circuit breaker
