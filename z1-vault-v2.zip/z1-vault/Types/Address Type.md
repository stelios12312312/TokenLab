---
type: type
base: "String"
---
# Address Type
**Base:** `String`

On-chain address
