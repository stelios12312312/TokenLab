---
type: type
base: "Float"
---
# Percentage Type
**Base:** `Float`

[0,1] percentage
