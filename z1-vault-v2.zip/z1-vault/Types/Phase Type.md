---
type: type
base: "Enum[pre_tge, post_tge, mature]"
---
# Phase Type
**Base:** `Enum[pre_tge, post_tge, mature]`

Protocol lifecycle phase
