---
type: type
base: "Any"
---
# Any Type
**Base:** `Any`

Flexible type for governance proposed values
