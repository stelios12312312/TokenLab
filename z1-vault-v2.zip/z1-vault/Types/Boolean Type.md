---
type: type
base: "Boolean"
---
# Boolean Type
**Base:** `Boolean`

True or false
