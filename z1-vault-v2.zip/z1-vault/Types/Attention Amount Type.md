---
type: type
base: "Float"
---
# Attention Amount Type
**Base:** `Float`

Verified attention units for A2E
