---
type: type
base: "Float"
---
# Price Type
**Base:** `Float`

Non-negative price in reference currency
