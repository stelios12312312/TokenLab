---
type: type
base: "Enum[inactive, proposed, cooling, executed]"
---
# Inflation Status Type
**Base:** `Enum[inactive, proposed, cooling, executed]`

Inflation mint gate
