---
type: type
base: "Enum[epochal, monthly, programmatic, governed, cliff_linear, policy_capped, milestone]"
---
# Schedule Type Type
**Base:** `Enum[epochal, monthly, programmatic, governed, cliff_linear, policy_capped, milestone]`

Vault release schedule
