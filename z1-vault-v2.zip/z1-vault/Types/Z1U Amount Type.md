---
type: type
base: "Float"
---
# Z1U Amount Type
**Base:** `Float`

Non-negative Z1U utility units
