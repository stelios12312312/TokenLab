---
type: type
base: "String"
---
# Proposal ID Type
**Base:** `String`

Unique governance proposal identifier
