---
type: type
base: "Enum[proposed, voting, passed, rejected, cooling, executed, expired]"
---
# Proposal Status Type
**Base:** `Enum[proposed, voting, passed, rejected, cooling, executed, expired]`

Proposal lifecycle
