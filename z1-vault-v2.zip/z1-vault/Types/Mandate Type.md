---
type: type
base: "Enum[settlement_only, milestones_and_bounties, routing, ...]"
---
# Mandate Type
**Base:** `Enum[settlement_only, milestones_and_bounties, routing, ...]`

Pool permitted operations
