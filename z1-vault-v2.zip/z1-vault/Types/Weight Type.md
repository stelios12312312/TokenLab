---
type: type
base: "Float"
---
# Weight Type
**Base:** `Float`

Non-negative governance weight
