---
type: type
base: "String"
---
# Hash Type
**Base:** `String`

Cryptographic hash
