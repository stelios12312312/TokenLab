---
type: type
base: "Enum[proposed, voting, approved, funded, delivered, abandoned]"
---
# Greenlight Status Type
**Base:** `Enum[proposed, voting, approved, funded, delivered, abandoned]`

Studio production lifecycle
