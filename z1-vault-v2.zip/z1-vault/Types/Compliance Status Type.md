---
type: type
base: "Enum[cleared, pending, restricted]"
---
# Compliance Status Type
**Base:** `Enum[cleared, pending, restricted]`

RWA investor KYC status
