---
type: type
base: "Enum[tier_0, tier_1, tier_2]"
---
# Governance Tier Type
**Base:** `Enum[tier_0, tier_1, tier_2]`

Parameter governance level
