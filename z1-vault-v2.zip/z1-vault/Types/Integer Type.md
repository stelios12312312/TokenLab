---
type: type
base: "Integer"
---
# Integer Type
**Base:** `Integer`

Non-negative integer
