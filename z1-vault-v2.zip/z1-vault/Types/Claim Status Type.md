---
type: type
base: "Enum[pending, pass, hold, deny]"
---
# Claim Status Type
**Base:** `Enum[pending, pass, hold, deny]`

G1 verification output. Includes pending state
