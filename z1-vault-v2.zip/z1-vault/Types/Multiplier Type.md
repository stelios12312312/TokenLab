---
type: type
base: "Float"
---
# Multiplier Type
**Base:** `Float`

Positive earning multiplier. Capped
