---
type: type
base: "String"
---
# Agent ID Type
**Base:** `String`

Unique agent identifier
