---
type: type
base: "String"
---
# Pool ID Type
**Base:** `String`

Unique pool identifier
