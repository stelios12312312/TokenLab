---
type: type
base: "Enum[campaign, production, prediction]"
---
# Escrow Type Type
**Base:** `Enum[campaign, production, prediction]`

Escrow subtype
