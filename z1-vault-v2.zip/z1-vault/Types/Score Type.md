---
type: type
base: "Float"
---
# Score Type
**Base:** `Float`

Bounded [0,1]
