---
type: type
base: "Enum[A, B, C]"
---
# Verification Tier Type
**Base:** `Enum[A, B, C]`

Proof quality tier
