---
type: type
base: "Integer"
---
# Epoch Type
**Base:** `Integer`

Non-negative timestep
