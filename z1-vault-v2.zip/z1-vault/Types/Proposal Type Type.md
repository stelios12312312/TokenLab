---
type: type
base: "Enum[parameter_change, greenlight_vote, constitutional_amendment, budget_allocation]"
---
# Proposal Type Type
**Base:** `Enum[parameter_change, greenlight_vote, constitutional_amendment, budget_allocation]`

Proposal classification
