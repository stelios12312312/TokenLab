---
type: type
base: "Enum[active, settling, settled, cancelled]"
---
# Escrow Status Type
**Base:** `Enum[active, settling, settled, cancelled]`

Escrow lifecycle
