---
type: type
base: "String"
---
# String Type
**Base:** `String`

Generic string
