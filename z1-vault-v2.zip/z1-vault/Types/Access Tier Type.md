---
type: type
base: "Enum[None, Bronze, Silver, Gold, Platinum]"
---
# Access Tier Type
**Base:** `Enum[None, Bronze, Silver, Gold, Platinum]`

Balance-based access
