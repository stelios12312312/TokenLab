---
type: wiring
id: "BW-10"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-10: Prediction market

**Phase:** Phase 2+3 | **Type:** Stack

Stake then resolution then redistribute. [[M46 Create escrow]] then [[P35 Prediction market resolution]] then payout + fee then [[M50 Close escrow]].
