---
type: wiring
id: "CW-09"
phase: "Phase 1"
wiring_type: "Stack"
---
# CW-09: Treasury health check

**Phase:** Phase 1 | **Type:** Stack

[[CA-09 Treasury health check]]. If treasury_health < theta_min, fire [[SYS_throttle Treasury Health Feedback]]. Runs after CW-07 so Treasury balance is current.
