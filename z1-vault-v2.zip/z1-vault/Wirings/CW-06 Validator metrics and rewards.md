---
type: wiring
id: "CW-06"
phase: "Phase 1"
wiring_type: "Parallel"
---
# CW-06: Validator metrics and rewards

**Phase:** Phase 1 | **Type:** Parallel

[[CA-06 Validator metrics and rewards]]. Performance metrics + [[G15a Validator Rewards]] stipend accrual from VRP.
