---
type: wiring
id: "CW-07"
phase: "Phase 1"
wiring_type: "Stack"
---
# CW-07: Treasury routing

**Phase:** Phase 1 | **Type:** Stack

Sequential priority: AR first ([[G11 AR Top-up]]), then CIP ([[G12 CIP Replenish]]), then VRP ([[G15_fund VRP Funding]]). All draw from Treasury. AR has absolute priority.
