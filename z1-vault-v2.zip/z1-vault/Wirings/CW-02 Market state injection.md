---
type: wiring
id: "CW-02"
phase: "Phase 1"
wiring_type: "Stack"
---
# CW-02: Market state injection

**Phase:** Phase 1 | **Type:** Stack

[[CA-02 Market state injection]] fires [[M02 Update market exogenous]]. Agent decisions depend on price. Sources: [[EXO-06 External Z1U price]], [[EXO-05 Macro sentiment]].
