---
type: wiring
id: "BW-11"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-11: Governance voting

**Phase:** Phase 2+3 | **Type:** Stack

Proposal: [[BA-11 Submit proposal]] then [[P22 Proposal eligibility]] then [[P24 Parameter bounds]] then [[M52 Create proposal]]. Voting: [[BA-12 Cast vote]] then [[P02 Eligibility revalidation]] then [[M28 Vote escrow lock]] then [[M53 Record vote]].
