---
type: wiring
id: "CW-03"
phase: "Phase 1"
wiring_type: "Parallel"
---
# CW-03: Vault release

**Phase:** Phase 1 | **Type:** Parallel

All 7 vaults evaluated per [[P17 Vault release schedule]]. Must run before BW-03 (settlement) so AR balance is current.
