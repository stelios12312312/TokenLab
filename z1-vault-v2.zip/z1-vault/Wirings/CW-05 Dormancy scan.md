---
type: wiring
id: "CW-05"
phase: "Phase 1"
wiring_type: "Parallel"
---
# CW-05: Dormancy scan

**Phase:** Phase 1 | **Type:** Parallel

[[CA-05 Dormancy scan]]. Increment counters, detect breaches, execute [[G17 ACR Expiry - Breakage]] actions.
