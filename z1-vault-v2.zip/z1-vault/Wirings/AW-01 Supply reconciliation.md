---
type: wiring
id: "AW-01"
phase: "Phase 4"
wiring_type: "Stack"
---
# AW-01: Supply reconciliation

**Phase:** Phase 4 | **Type:** Stack

Recompute all derived state on [[Global]] and [[Z1U Token Ledger]]. Z1U_Circulating, velocity, etc. Run cross-entity invariant assertions. If any fail, simulation halts.
