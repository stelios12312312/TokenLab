---
type: wiring
id: "BW-09"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-09: Production lifecycle

**Phase:** Phase 2+3 | **Type:** Stack

Stake then propose then vote then fund then deliver then settle. [[P33 Production funding]] then [[M46 Create escrow]]. Per milestone: [[P34 Milestone verification]] then [[M47 Escrow payout]] or [[M51 Slash production escrow]].
