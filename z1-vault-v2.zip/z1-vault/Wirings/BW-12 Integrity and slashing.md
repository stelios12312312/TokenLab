---
type: wiring
id: "BW-12"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-12: Integrity and slashing

**Phase:** Phase 2+3 | **Type:** Stack

[[G13a Z1U Slashing]] and [[G13b ACR Voiding]]. ACR fraud: [[P26 Hold decision]] then [[M07 Hold ACR]] then [[P27 Hold resolution]] then [[M09 Void ACR]]. Z1U slash: [[P28 Slash amount]] then [[M33 Slash agent]] (to Treasury). Due process: evidence disclosure, 14-day appeal, independent review.
