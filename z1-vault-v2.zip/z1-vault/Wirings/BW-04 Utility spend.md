---
type: wiring
id: "BW-04"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-04: Utility spend

**Phase:** Phase 2+3 | **Type:** Stack

[[G5a Utility Spend]] + [[G5b Protocol Fee]] + [[G5c Sink-Burn]]. Atomic three-way split from single transaction. [[BA-04 Utility spend]] fires [[P14 Utility spend split]].
