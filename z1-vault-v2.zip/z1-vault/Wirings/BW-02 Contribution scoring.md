---
type: wiring
id: "BW-02"
phase: "Phase 2+3"
wiring_type: "Parallel"
---
# BW-02: Contribution scoring

**Phase:** Phase 2+3 | **Type:** Parallel

[[G2 Contribution to ACR]]. Hybrid control+boundary. [[P06 Anomaly detection]] then [[P05 PCS computation]] then [[M05 Issue ACR]] or [[M07 Hold ACR]]. Also [[P09 Curation-scout reward]] for A2/A3.
