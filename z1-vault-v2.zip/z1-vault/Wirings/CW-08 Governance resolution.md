---
type: wiring
id: "CW-08"
phase: "Phase 1"
wiring_type: "Parallel"
---
# CW-08: Governance resolution

**Phase:** Phase 1 | **Type:** Parallel

[[CA-08 Governance resolution]]. Resolve expired proposals. Execute passed proposals. Release vote escrows.
