---
type: wiring
id: "epoch_pipeline"
---
# Epoch execution pipeline

## Phase 1: System updates (strict order)
[[CW-01 Epoch tick]] then [[CW-02 Market state injection]] then [[CW-03 Vault release]] then [[CW-04 ACR vesting transition]] then [[CW-05 Dormancy scan]] then [[CW-06 Validator metrics and rewards]] then [[CW-07 Treasury routing]] then [[CW-08 Governance resolution]] then [[CW-09 Treasury health check]]

## Phase 2+3: Agent actions + system responses (parallelizable across agents)
[[BW-01 Claim and verification]] | [[BW-02 Contribution scoring]] | [[BW-03 Settlement]] | [[BW-04 Utility spend]] | [[BW-05 Governance lock-unlock]] | [[BW-06 Governance delegation]] | [[BW-07 Transfer-trade]] | [[BW-08 Campaign lifecycle]] | [[BW-09 Production lifecycle]] | [[BW-10 Prediction market]] | [[BW-11 Governance voting]] | [[BW-12 Integrity and slashing]] | [[BW-13 Operational outflow]]

## Phase 4: Accounting and invariant assertions
[[AW-01 Supply reconciliation]] then [[AW-02 ACR aggregation]] then [[AW-03 Governance aggregation]] then [[AW-04 Pool health metrics]]

## Critical ordering dependencies
- CW-03 (vault release) BEFORE BW-03 (settlement): AR balance must be current
- CW-04 (vesting) BEFORE BW-03 (settlement): acr_available must be current
- CW-07: AR top-up BEFORE CIP replenish BEFORE VRP funding: AR has Treasury priority
- CW-09 (throttle check) AFTER CW-07: Treasury balance must reflect all routing
- BW-02 (scoring) BEFORE BW-03 (settlement): holds must be set before settlement runs
- All Phase 2+3 BEFORE Phase 4: accounting must reflect all state changes

## Inventory
- Control wirings (Phase 1): CW-01 to CW-09 = 9
- Boundary wirings (Phase 2+3): BW-01 to BW-13 = 13
- Accounting wirings (Phase 4): AW-01 to AW-04 = 4
- Total: 26 wirings composing 44 policies and 57 mechanisms
