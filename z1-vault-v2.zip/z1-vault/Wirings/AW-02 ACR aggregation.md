---
type: wiring
id: "AW-02"
phase: "Phase 4"
wiring_type: "Stack"
---
# AW-02: ACR aggregation

**Phase:** Phase 4 | **Type:** Stack

Recompute [[ACR Ledger]] system aggregates. settlement_pressure_ratio = ACR_Available(t) / AR(t). Assert per-user conservation law.
