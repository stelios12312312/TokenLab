---
type: wiring
id: "BW-06"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-06: Governance delegation

**Phase:** Phase 2+3 | **Type:** Stack

[[G18 Governance Delegation]] and [[G18' Governance Revocation]]. [[BA-07 Delegate governance]] then [[P25 Delegation policy]] then [[M26 Delegate governance]]. Revocation: [[BA-08 Revoke delegation]] then [[M27 Revoke delegation]]. Cooldown enforced.
