---
type: wiring
id: "BW-05"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-05: Governance lock-unlock

**Phase:** Phase 2+3 | **Type:** Stack

[[G6 Governance Stake]] and [[G6' Governance Unlock]]. Lock: [[BA-05 Governance lock]] then [[P36 Governance lock eligibility]] then [[M23 Governance lock]] then [[P21 Governance weight computation]] then [[M25 Update governance weight]]. Unlock: [[BA-06 Governance unlock]] then [[P39 Unlock eligibility]] then [[M24 Governance unlock]].
