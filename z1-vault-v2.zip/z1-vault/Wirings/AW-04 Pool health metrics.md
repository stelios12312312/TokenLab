---
type: wiring
id: "AW-04"
phase: "Phase 4"
wiring_type: "Stack"
---
# AW-04: Pool health metrics

**Phase:** Phase 4 | **Type:** Stack

Compute [[OBS-05 AR_ratio]], [[OBS-06 treasury_runway]], settlement_queue_depth, VRP runway. Dashboard KPIs.
