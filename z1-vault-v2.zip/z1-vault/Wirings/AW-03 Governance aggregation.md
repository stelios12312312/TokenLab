---
type: wiring
id: "AW-03"
phase: "Phase 4"
wiring_type: "Stack"
---
# AW-03: Governance aggregation

**Phase:** Phase 4 | **Type:** Stack

Recompute total governance weight including delegations. Check concentration caps per [[PAR-30 governance_concentration_cap]].
