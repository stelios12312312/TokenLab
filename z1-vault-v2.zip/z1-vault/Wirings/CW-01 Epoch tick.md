---
type: wiring
id: "CW-01"
phase: "Phase 1"
wiring_type: "Stack"
---
# CW-01: Epoch tick

**Phase:** Phase 1 | **Type:** Stack

Runs first. [[CA-01 Epoch tick]] fires [[M01 Increment epoch]]. Resets per-epoch accumulators across all pools.
