---
type: wiring
id: "BW-08"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-08: Campaign lifecycle

**Phase:** Phase 2+3 | **Type:** Stack

[[G8 Campaign Deposit]] then [[G9a Campaign Payout]] / [[G9b Campaign Fee]] / [[G9c Campaign Burn]]. Creation: [[BA-10 Campaign deposit]] then [[P31 Campaign creation]] then [[M46 Create escrow]]. Settlement: [[P32 Campaign verification]] then [[P15 Campaign fee split]] then payout + fee + burn then [[M50 Close escrow]].
