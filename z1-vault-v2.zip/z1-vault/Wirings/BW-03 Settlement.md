---
type: wiring
id: "BW-03"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-03: Settlement

**Phase:** Phase 2+3 | **Type:** Stack

[[G3 ACR Settlement]]. Most complex wiring. [[BA-03 Initiate settlement]] then [[P02 Eligibility revalidation]] then [[P10 Settlement eligibility]] then [[P11 Settlement ratio]] then [[P13 Settlement queue]] then [[M10 Settle ACR]] then [[M41 Pool outflow]] on AR then [[M15 Transfer Z1U]] to agent. Depends on CW-03 and CW-04.
