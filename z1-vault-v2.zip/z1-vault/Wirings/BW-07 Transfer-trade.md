---
type: wiring
id: "BW-07"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-07: Transfer-trade

**Phase:** Phase 2+3 | **Type:** Stack

[[G7 Transfer - Market]]. Simplest wiring. [[BA-09 Transfer-trade]] then [[M15 Transfer Z1U]] then [[M21 Update access tier]]. No policy gating beyond balance check.
