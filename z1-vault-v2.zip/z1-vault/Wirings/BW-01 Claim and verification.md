---
type: wiring
id: "BW-01"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-01: Claim and verification

**Phase:** Phase 2+3 | **Type:** Stack

[[G0 Opt-in]] then [[G1 Verification]]. [[BA-01 Agent opt-in]] fires [[M19 Create agent]]. [[BA-02 Submit identity proofs]] fires [[P01 Verification policy]] then [[M04 Set claim status]].
