---
type: wiring
id: "BW-13"
phase: "Phase 2+3"
wiring_type: "Stack"
---
# BW-13: Operational outflow

**Phase:** Phase 2+3 | **Type:** Stack

[[G16 Operational Outflow]]. [[P44 Operational outflow]] then [[M41 Pool outflow]] on Treasury. Governance-approved. Cannot fund AR-eligible purposes.
