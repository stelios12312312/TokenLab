---
type: wiring
id: "CW-04"
phase: "Phase 1"
wiring_type: "Parallel"
---
# CW-04: ACR vesting transition

**Phase:** Phase 1 | **Type:** Parallel

[[G14 Vesting Progression]] for all A_ACR agents. [[CA-04 ACR vesting transition]] fires [[P12 Vesting schedule]] then [[M06 Vest ACR]]. Must run before BW-03.
