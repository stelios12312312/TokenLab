---
type: state
entity: "[[Escrow]]"
entity_id: E6
---
# Escrow State

## Shared

| Variable | Type | Description |
|----------|------|-------------|
| escrow_id | String | Unique |
| escrow_type | Enum(campaign, production, prediction) | Subtype |
| budget_total | Float | Deposited at creation. Immutable |
| budget_remaining | Float | Still held. Zero = fully settled |
| status | Enum(active, settling, settled, cancelled) | Lifecycle |
| creator_agent_id | AgentID | Who created (Brand for campaign, Studio for production) |
| creation_epoch | Nat | When created |
| fee_split | Dict | % to recipients / treasury / burn |

## Campaign-specific (funded via [[G8 Campaign Deposit]], settled via [[G9a Campaign Payout]])
- attention_target: verified attention needed
- attention_delivered: accumulated so far

## Production-specific (funded via greenlight, milestone-gated)
- milestone_count, milestones_verified, tranche_amount, funding_source_pool

## Prediction-specific
- outcome_options, stakes_by_option, resolution_epoch
