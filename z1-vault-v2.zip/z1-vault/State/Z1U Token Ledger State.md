---
type: state
entity: "[[Z1U Token Ledger]]"
entity_id: E3
---
# Z1U Token Ledger State

## Primary state

| Variable | Type | Description |
|----------|------|-------------|
| total_supply | Float | Live supply = minted - burned |
| total_cap | Float | 10^12 constitutional limit (Z1U_TotalCap) |
| transfer_volume_epoch | Float | Z1U transferred this epoch. Resets |
| mint_authority | Address | Address(es) with mint permission |
| burn_registry | Dict | Per-source burn accounting: G5c, G9c, G13a, A2E, breakage |
| pause_state | Enum(active, paused) | Emergency circuit breaker |

## Invariants
- total_supply = sum(agent.balance + agent.locked) + sum(pool.balance) + sum(escrow.remaining)
- total_supply = [[Global]].Z1U_Minted - [[Global]].Z1U_Burned
- total_supply <= total_cap
- If pause_state = paused then no transfers, mints, burns execute
