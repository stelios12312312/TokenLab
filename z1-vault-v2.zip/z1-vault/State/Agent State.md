---
type: state
entity: "[[Agent]]"
entity_id: E4
---
# Agent State

Universal state + conditional subtype fields. See [[Agent Registry]] for full A1-A14 definitions.

## Universal (every agent, from DOC-013 section 2.5)

| Variable | Type | Description |
|----------|------|-------------|
| agent_id | String | Unique. Immutable |
| agent_type | Set[A1..A14] | Multi-type flagging possible |
| z1u_balance(a,t) | Float | Spendable Z1U. View into [[Z1U Token Ledger]] |
| z1u_staked(a,t) | Float | Z1U locked for governance/access via [[G6 Governance Stake]] |
| z1u_escrowed(a,t) | Float | Z1U in pending escrow |
| acr_record(a,t) | Ref | Full ACR state (reference to [[ACR Ledger]]) |
| pcs_score(a,t) | Float | Participation Contribution Score |
| tier(a,t) | Enum(None, Bronze, Silver, Gold, Platinum) | Access tier from Z1U balance |
| claim_status(a,t) | Enum(pending, pass, hold, deny) | Re-evaluated at benefit gates |
| gov_weight(a,t) | Float | Effective governance voting power |
| reputation(a,t) | Float | Role-specific reputation score |
| delegations_in(a,t) | Int | Count of active delegations received |
| delegated_weight(a,t) | Float | Aggregate governance weight received via delegation |
| registration_epoch | Nat | When entered system |
| is_active | Boolean | False = exited/banned |
| adversarial_mode | Boolean | Sim-only. A13 behavioral flag |

## Audience layer (A1-A5, ACR participants)

| Variable | Subtypes | Description |
|----------|----------|-------------|
| loyalty_multiplier | A1-A5 | Tenure-based earning multiplier |
| dormancy_counter | A1-A5 | Epochs since last contribution |
| last_contribution_epoch | A1-A5 | When last earned ACR |
| curation_accuracy | A2 | Rolling signal accuracy |
| panel_memberships | A2 | Which selection panels |
| curation_streak | A2 | Consecutive active epochs |
| referral_count | A3 | Creators referred |
| referral_conversion_rate | A3 | % progressing through stages |
| bounty_stage_active | A3 | Per referral: shortlist/pilot/greenlight |
| scout_reputation | A3 | From conversion + fraud-free record |
| pod_id | A4 | Which pod(s) |
| pod_role | A4 | Role within pod |
| milestone_status | A4 | pending/delivered/verified/slashed |
| CIP_entitlement | A4 | Approved allocation pending delivery |
| content_output_count | A4 | Delivered content items |
| producer_stake_locked | A5 | Z1U locked for greenlight |
| stake_lock_expiry | A5 | When producer stake unlocks |
| greenlight_status | A5 | Production lifecycle status |
| production_escrow_id | A5 | Ref to [[Escrow]] |
| delivery_milestones | A5 | Per-production milestone tracking |

## Infrastructure (A6, A7)

| Variable | Subtypes | Description |
|----------|----------|-------------|
| policy_actions_this_epoch | A6 | Action count per epoch |
| treasury_draw_cumulative | A6 | Total drawn from Treasury |
| verifier_bond_locked | A7 | Bonded integrity collateral. Slashable via [[G13a Z1U Slashing]] |
| uptime | A7 | Node availability (rolling average) |
| fraud_catch_rate | A7 | Detections / attestations |
| attestation_accuracy | A7 | Correct / total attestations |
| stipend_accrued | A7 | Earned unpaid rewards from [[G15a Validator Rewards]] |
| slashing_history | A7 | Past slash events. Escalating penalties |

## Capital + external (A10, A11, A12)

| Variable | Subtypes | Description |
|----------|----------|-------------|
| campaign_ids_active | A10 | Active campaign escrow refs |
| total_deposited_cumulative | A10 | Lifetime campaign deposits via [[G8 Campaign Deposit]] |
| campaign_success_rate | A10 | % campaigns hitting targets |
| rwa_position_value | A11 | Ring-fenced instrument value |
| compliance_status | A11 | KYC/suitability for [[G10 RWA Fee Route]] |
| rwa_fee_contribution | A11 | Cumulative fees to Treasury |
| trade_volume_epoch | A12 | Z1U traded via [[G7 Transfer - Market]] |
| avg_hold_duration | A12 | Mean epochs between acquire and dispose |

## Governance delegate (A14)

| Variable | Description |
|----------|-------------|
| delegators | Set of agent_ids who delegated to this agent via [[G18 Governance Delegation]] |
| delegated_weight_total | Aggregate received governance weight |
| delegation_trust_score | Track record of representing constituent interests |

## Invariants
- z1u_balance + z1u_staked >= 0 (no negative balances)
- If claim_status != pass then no G3, G4, G6, G9, G10 benefit delivery
- If is_active = false then no state mutations
- tier = deterministic f(z1u_balance) per tier_thresholds parameter
- gov_weight = 0 if claim_status != pass or z1u_staked = 0
