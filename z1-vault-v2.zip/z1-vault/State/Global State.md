---
type: state
entity: "[[Global]]"
entity_id: E1
---
# Global State

## Primary state

| Variable | Type | Description |
|----------|------|-------------|
| epoch | Nat | Current timestep. Monotonically increasing |
| phase | Enum(pre_tge, post_tge, mature) | Protocol lifecycle phase |
| Z1U_Minted | Float | Total created. Starts 1T. Only grows via inflation mint |
| Z1U_Burned | Float | Cumulative removal. Sources: [[G5c Sink-Burn]], [[G9c Campaign Burn]], [[G13a Z1U Slashing]], A2E, breakage |
| inflation_status | Enum(inactive, proposed, cooling, executed) | Inflation mint gate |
| market_price | Float | Exogenous. External Z1U price |
| market_volume | Float | Exogenous. External trading volume per epoch |

## Derived state
- Z1U_Circulating = Minted - sum(pool.balance) - sum(escrow) - sum(agent.locked) - Burned
- Z1U_LockedByVault = sum(vault.remaining)
- Z1U_Escrowed = sum(escrow.budget_remaining)
- Z1U_GovLocked = sum(agent.z1u_staked)
- velocity = transfer_volume_epoch / circulating_supply

## Invariants
- Minted = Circulating + LockedByVault + Escrowed + GovLocked + AgentLocked + Burned
- Minted <= total_cap (unless inflation mint executed)
- Z1U_Burned monotonically non-decreasing
- epoch monotonically increasing
