---
type: state
entity: "[[ACR Ledger]]"
entity_id: E2
---
# ACR Ledger State

Per-user indexed. A_ACR := {A1, A2, A3, A4, A5} - all types that earn ACR.

## Per-user state

| Variable | Type | Description |
|----------|------|-------------|
| acr_issued(a,t) | Float | Total ACR ever posted. Only increases via [[G2 Contribution to ACR]] |
| acr_vesting(a,t) | Float | Issued but time-locked. Transitions to Available via [[G14 Vesting Progression]] |
| acr_available(a,t) | Float | Vested. Eligible for [[G3 ACR Settlement]] |
| acr_settled(a,t) | Float | Converted to Z1U via G3. Monotonically increasing |
| acr_held(a,t) | Float | Frozen due to verification holds/appeals |
| acr_voided(a,t) | Float | Reversals under narrow legal carve-outs via [[G13b ACR Voiding]] |
| claim_status | Enum(pending, pass, hold, deny) | Set at [[G1 Verification]], re-evaluated at every benefit gate |
| verification_tier | Enum(A, B, C) | Proof quality tier. Affects PCS weight caps |
| pcs_score(a,t) | Float[0,1] | Current PCS score |
| last_contribution_epoch | Nat | When last earned ACR. Drives dormancy |
| dormancy_counter | Nat | Epochs since last contribution. [[G17 ACR Expiry - Breakage]] trigger |

## Conservation law
acr_issued(a,t) = acr_vesting(a,t) + acr_available(a,t) + acr_settled(a,t) + acr_held(a,t) + acr_voided(a,t)

## System aggregates
- ACR_Issued(t) := sum over A_ACR of acr_issued(a,t)
- ACR_Vesting(t), ACR_Available(t), ACR_Settled(t) - same pattern
- settlement_pressure_ratio = ACR_Available(t) / AR(t) - if > 1 then AR cannot cover

## Invariants
- Per user: conservation law holds at every timestep
- System: ACR_Settled(t) * settlement_ratio <= AR.cumulative_outflow
- If claim_status != pass then acr_available cannot decrease via G3
- No ACR transfer between users (soulbound enforcement)
