---
type: state
entity: "[[Governance Proposal]]"
entity_id: E7
---
# Governance Proposal State

| Variable | Type | Description |
|----------|------|-------------|
| proposal_id | String | Unique |
| proposal_type | Enum(parameter_change, greenlight_vote, constitutional_amendment, budget_allocation) | Type |
| proposer_agent_id | AgentID | Must meet eligibility (Silver tier minimum per DOC-019) |
| status | Enum(proposed, voting, passed, rejected, cooling, executed, expired) | Lifecycle |
| vote_tally_for | Float | Governance weight supporting |
| vote_tally_against | Float | Governance weight opposing |
| quorum_threshold | Float | Min weight for validity |
| pass_threshold | Float | % for-votes needed |
| voting_start_epoch | Nat | When voting opens |
| voting_end_epoch | Nat | When voting closes |
| cooling_period_end | Nat | Constitutional: mandatory wait |
| target_parameter | String | Which parameter changes |
| proposed_value | Any | New value (within bounded range) |

## Invariants
- Only agents with gov_weight > 0 and claim_status = pass can vote
- Constitutional: 90% + Trustee (A9) concurrence + 60-day cooling
- proposed_value within bounded range per parameter
