---
type: state
entity: "[[Pool]]"
entity_id: E5
---
# Pool State

## Pools (from DOC-013 section 2.3)

| Pool | Symbol | Description |
|------|--------|-------------|
| Audience Reserve | AR(t) | Funds [[G3 ACR Settlement]]. Floor enforced |
| Creator Incentives | CIP(t) | Funds [[G4 Incentive Distribution]] |
| Treasury | T(t) | Central budget. Receives fees, funds G11/G12/G15/G16 |
| Campaign Escrow | CE(t) | Aggregate campaign escrow balance |
| Validator Reward Pool | VRP(t) | Funds [[G15a Validator Rewards]] and [[G15b Verifier Bond Return]] |

## Pool conservation
AR(t) + CIP(t) + T(t) + CE(t) + VRP(t) <= Z1U_LockedByBucket(t) + Z1U_Escrowed(t)

## Shared state (all pool instances)

| Variable | Type | Description |
|----------|------|-------------|
| pool_id | String | Unique (AR_vault, AR_pool, etc) |
| pool_type | Enum(vault, operational) | Genesis vault vs operational |
| balance | Float | Current Z1U held |
| cumulative_inflow | Float | Lifetime received |
| cumulative_outflow | Float | Lifetime distributed |

## Vault-specific (7 instances: AR=30%, CIP=20%, Treasury=15%, EcoDev=20%, LiqOps=5%, StratPart=2%, Team=8%)

| Variable | Description |
|----------|-------------|
| allocation | Fixed at genesis |
| released | Cumulative unlocked |
| remaining | allocation - released - expired |
| schedule_type | Release schedule (epochal, cliff+linear, governed, etc) |
| cliff_epoch | First release epoch |
| release_rate | Z1U per epoch |
| destination_pool | Where released tokens go |

## AR floor constraint (from DOC-013 section 2.4)
AR(t) >= alpha_floor * Z1U_Circulating(t)
where alpha_floor >= 0.25 (constitutional parameter)
If AR(t) < floor: trigger [[G11 AR Top-up]]
