---
type: invariants
---
# Cross-entity invariants

## Z1U conservation ([[Z1U Token Ledger]] <-> [[Agent]] <-> [[Pool]] <-> [[Escrow]])
- total_supply = sum(agent.z1u_balance + agent.z1u_staked) + sum(pool.balance) + sum(escrow.budget_remaining)
- total_supply = [[Global]].Z1U_Minted - [[Global]].Z1U_Burned

## ACR conservation (per user, from DOC-013 section 2.1)
- acr_issued(a,t) = acr_vesting(a,t) + acr_available(a,t) + acr_settled(a,t) + acr_held(a,t) + acr_voided(a,t)

## ACR to Z1U bridge ([[ACR Ledger]] <-> [[Pool]] AR)
- ACR_Settled(t) * settlement_ratio <= AR.cumulative_outflow
- Every [[G3 ACR Settlement]] event: acr_available decreases on E2, AR balance decreases on E5

## AR floor constraint (from DOC-013 section 2.4)
- AR(t) >= alpha_floor * Z1U_Circulating(t) where alpha_floor >= 0.25

## Pool conservation
- AR(t) + CIP(t) + T(t) + CE(t) + VRP(t) <= Z1U_LockedByBucket(t) + Z1U_Escrowed(t)

## Governance anti-capture ([[Agent]] <-> [[ACR Ledger]] <-> [[Governance Proposal]])
- gov_weight > 0 requires claim_status = pass AND z1u_staked > 0
- Z1U alone cannot grant governance (PAR-10)

## Vault to pool flow ([[Pool]] vault <-> [[Pool]] operational)
- vault.released = destination_pool.cumulative_inflow (from vault source)
- sum(all vault.allocation) = 10^12 = total_cap (at genesis)

## Delegation constraints
- No self-delegation: delegator != delegate
- Delegation depth < max_depth ([[PAR-42 delegation_depth_max]])
- Both parties claim_status = pass
